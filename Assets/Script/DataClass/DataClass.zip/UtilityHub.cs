using System.Collections.Generic;
using System.Text;
using UnityEngine;
using static ShapeDefenseSpace.GameData;
using static ShapeDefenseSpace.PublicData;

namespace ShapeDefenseSpace {
    public class UtilityHub {
        // query string�� �����ϱ� ���� string builder
        public static StringBuilder query_builder = new(100);

        public static void PageHeaderSetting() {
            if (!GameObject.Find("Header").activeSelf) GameObject.Find("Header").SetActive(true);
            HeaderSetting.Instance.HeaderSet();
        }


        /// <summary>
        /// ������ �ʵ��� ���� ��ġ�� �����ϴ� �Լ�
        /// </summary>
        /// <param name="a">30�� Ȯ�� 1</param>
        /// <param name="b">30�� Ȯ�� 2</param>
        /// <param name="c">30�� Ȯ�� 3</param>
        /// <param name="d">10/3�� Ȯ�� 4</param>
        /// <param name="e">10/3�� Ȯ�� 5</param>
        /// <param name="f">10/3�� Ȯ�� 5</param>
        public static void UnitCreateRandomField(int a, int b, int c, int d, int e, int f) {

            // ������ ����
            // ������ ��ġ�� �������� �����ؾ���
            while (datahub.LeftStageField > 0 ) {
                int pos = Random.Range(1, datahub.StageFieldNumber+1); // ((int)Time.time % datahub.StageFieldNumber) + 1;
                GameObject tmp_field = datahub.StageField[pos] as GameObject;
                // 0 �� �ƴϸ� ���⿡ �ֱ�
                if (tmp_field.GetComponent<Field>().UnitId == 0) {
                    // ���ֵ� 1~5 �� �ϳ� �����ϰ� �ֱ�
                    // ���� �������ִ� ��� ���� ���� �� �� �־�� �� -> ������ ���� > ���� ������ ������
                    int tmp_unit_id = Random.Range(1, 991);

                    if (tmp_unit_id >= 1 && tmp_unit_id < 301) {
                        // a
                        datahub.UnitCounter[a]++;
                        tmp_field.GetComponent<Field>().UnitId = a;
                    }
                    else if (tmp_unit_id >= 301 && tmp_unit_id < 601) {
                        // b
                        datahub.UnitCounter[b]++;
                        tmp_field.GetComponent<Field>().UnitId = b;
                    }
                    else if (tmp_unit_id >= 601 && tmp_unit_id < 901) {
                        // c
                        datahub.UnitCounter[c]++;
                        tmp_field.GetComponent<Field>().UnitId = c;
                    }

                    // 10 �� 3����� ���
                    else if (tmp_unit_id >= 901 && tmp_unit_id < 1001) {
                        int hidden_piece = Random.Range(1, 1000);
                        if (hidden_piece >= 1 && hidden_piece < 334) {
                            // d
                            datahub.UnitCounter[d]++;
                            tmp_field.GetComponent<Field>().UnitId = d;
                        }
                        else if (hidden_piece >= 334 && hidden_piece < 667) {
                            // e
                            datahub.UnitCounter[e]++;
                            tmp_field.GetComponent<Field>().UnitId = e;
                        }
                        else if (hidden_piece >= 667 && hidden_piece < 1000) {
                            // e
                            datahub.UnitCounter[f]++;
                            tmp_field.GetComponent<Field>().UnitId = f;
                        }
                    }

                    // �ְ� ���ѷ��� ����
                    datahub.StageField[pos] = tmp_field;
                    datahub.LeftStageField--;
                    // ���� �̹��� ��ȭ
                    UnitFieldChange((datahub.StageField[pos] as GameObject).transform.position, 1);

                    // ���� ������ ���������ִٸ� ��Ȱ��
                    if (datahub.IsShowUnitCount) {
                        UnitCounterPool.Instance.ShowUnitCount();
                    }
                    break;
                }
            }
        }


        public static void UnitFieldChange(Vector3 pos, int type) {
            switch (type) {
                case 0:
                    datahub.UnitMap.SetTile(datahub.UnitMap.WorldToCell(pos), empty_base);
                    break;
                case 1:
                    datahub.UnitMap.SetTile(datahub.UnitMap.WorldToCell(pos), unit_ani_tile);
                    break;
            }
            
        }

        /// <summary>
        /// id�� ���� resoruces ���� �ε��� sprite�� path�� ����
        /// </summary>
        /// <param name="id">unit id for sprite image</param>
        public static Sprite GetSprite(int id) {
            Sprite path = id switch {
                1001 => unit_e_circle,
                1002 => unit_e_triangle,
                1003 => unit_e_square,
                1004 => unit_e_star,
                1005 => unit_e_moon,
                1006 => unit_e_sun,

                2001 => unit_d_circle,
                2002 => unit_d_triangle,
                2003 => unit_d_square,

                3001 => unit_c_circle_1,
                3002 => unit_c_circle_2,
                3003 => unit_c_circle_3,
                3004 => unit_c_triangle_1,
                3005 => unit_c_triangle_2,
                3006 => unit_c_triangle_3,
                3007 => unit_c_square_1,
                3008 => unit_c_square_2,
                3009 => unit_c_square_3,
                3010 => unit_c_amalgation_1,
                3011 => unit_c_amalgation_2,
                3012 => unit_c_amalgation_3,
                3013 => unit_c_star,
                3014 => unit_c_moon,
                3015 => unit_c_sun,

                4001 => unit_b_circle_1,
                4002 => unit_b_circle_2,
                4003 => unit_b_circle_3,
                4004 => unit_b_triangle_1,
                4005 => unit_b_triangle_2,
                4006 => unit_b_triangle_3,
                4007 => unit_b_square_1,
                4008 => unit_b_square_2,
                4009 => unit_b_square_3,
                4010 => unit_b_star,
                4011 => unit_b_moon,
                4012 => unit_b_sun,

                5001 => unit_a_circle,
                5002 => unit_a_triangle,
                5003 => unit_a_square,
                5004 => unit_a_star,
                5005 => unit_a_moon,
                5006 => unit_a_sun,

                6001 => unit_s_circle,
                6002 => unit_s_triangle,
                6003 => unit_s_square,
                6004 => unit_s_star,
                6005 => unit_s_moon,
                6006 => unit_s_sun,

                // ������
                301 => unit_c_circle_0,
                302 => unit_c_triangle_0,
                303 => unit_c_square_0,
                304 => unit_c_star_0,
                305 => unit_c_moon_0,
                306 => unit_c_sun_0,

                401 => unit_b_circle_0,
                402 => unit_b_triangle_0,
                403 => unit_b_square_0,
                404 => unit_b_star_0,
                405 => unit_b_moon_0,
                406 => unit_b_sun_0,

                501 => unit_a_harmony_of_star_moon,
                502 => unit_a_harmony_of_sun_moon,
                503 => unit_a_harmony_of_sun_star,

                7001 => poison_border,
                7002 => blust_border,
                7003 => paralysis_border,

                _ => null,
            };

            return path;
        }

        /// <summary>
        /// ���� �������� Ȯ���ϰ� ������ �����ϴ� �Լ�
        /// </summary>
        /// datahub�� ����� �����͸� ������� ����Ǳ� ������ param ����
        private static CombineFunction tmp_combinefuntion = new();
        public static void CombineCheck(int combine_id) {

            // ��� ����
            // base id
            // target result
            // datahub �� unitcounter
            // stage field

            // base id instance
            if(datahub.CombineWaitingPos <= 0) {
                AnnounceControll.Instance.AnnounceOn(1);
                return;
            }
            GameObject tmp_field = datahub.StageField[datahub.CombineWaitingPos] as GameObject;
            int base_id = tmp_field.GetComponent<Field>().UnitId;
            Unit base_unit = datahub.Unit_dic[base_id] as Unit;

            // ���ս��� ���� ���̵� ���� Ȯ���� ���ս��� ����            
            int size = base_unit.CombFucntion.Count;
            for (int i = 0; i < size; i++) {
                if (base_unit.CombFucntion[i].Id == combine_id) {
                    tmp_combinefuntion = base_unit.CombFucntion[i];
                    break;
                }
            }
            bool can = false;
            // ���� ������ �� Ȯ��
            // �ִ� �ߺ����� 3��
            switch (tmp_combinefuntion.NeedCount) {
                case 1:
                    // ���� baseid �� ���ٸ� 2���� , �ٸ��ٸ� 1���� �ִ��� Ȯ��
                    if (base_unit.Id == tmp_combinefuntion.A) {
                        if (datahub.UnitCounter[tmp_combinefuntion.A] >= 2)
                            can = true;
                        else
                            can = false;
                    }
                    else {
                        if (datahub.UnitCounter[tmp_combinefuntion.A] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    break;
                case 2:
                    if (base_unit.Id == tmp_combinefuntion.A || tmp_combinefuntion.A == tmp_combinefuntion.B) {
                        if (datahub.UnitCounter[tmp_combinefuntion.A] >= 2 && datahub.UnitCounter[tmp_combinefuntion.B] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    else if (base_unit.Id == tmp_combinefuntion.A && tmp_combinefuntion.A == tmp_combinefuntion.B) {
                        if (datahub.UnitCounter[base_unit.Id] >= 3)
                            can = true;
                        else
                            can = false;
                    }
                    else {
                        if (datahub.UnitCounter[tmp_combinefuntion.A] >= 1 && datahub.UnitCounter[tmp_combinefuntion.B] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    break;
                case 3:
                    if (base_unit.Id == tmp_combinefuntion.A || tmp_combinefuntion.A == tmp_combinefuntion.B || tmp_combinefuntion.A == tmp_combinefuntion.C) {
                        if (datahub.UnitCounter[tmp_combinefuntion.A] >= 2 && datahub.UnitCounter[tmp_combinefuntion.B] >= 1 && datahub.UnitCounter[tmp_combinefuntion.C] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    else if (base_unit.Id == tmp_combinefuntion.B || tmp_combinefuntion.B == tmp_combinefuntion.C) {
                        if (datahub.UnitCounter[tmp_combinefuntion.B] >= 2 && datahub.UnitCounter[tmp_combinefuntion.A] >= 1 && datahub.UnitCounter[tmp_combinefuntion.C] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    else if (base_unit.Id == tmp_combinefuntion.C) {
                        if (datahub.UnitCounter[tmp_combinefuntion.C] >= 2 && datahub.UnitCounter[tmp_combinefuntion.B] >= 1 && datahub.UnitCounter[tmp_combinefuntion.A] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    else {
                        if (datahub.UnitCounter[tmp_combinefuntion.A] >= 1 && datahub.UnitCounter[tmp_combinefuntion.B] >= 1 && datahub.UnitCounter[tmp_combinefuntion.C] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    break;
                case 4:
                    if (base_unit.Id == tmp_combinefuntion.A || tmp_combinefuntion.A == tmp_combinefuntion.B || tmp_combinefuntion.A == tmp_combinefuntion.C || tmp_combinefuntion.A == tmp_combinefuntion.D) {
                        if (datahub.UnitCounter[tmp_combinefuntion.A] >= 2 && datahub.UnitCounter[tmp_combinefuntion.B] >= 1 && datahub.UnitCounter[tmp_combinefuntion.C] >= 1 && datahub.UnitCounter[tmp_combinefuntion.D] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    else if (base_unit.Id == tmp_combinefuntion.B || tmp_combinefuntion.B == tmp_combinefuntion.C || tmp_combinefuntion.B == tmp_combinefuntion.D) {
                        if (datahub.UnitCounter[tmp_combinefuntion.B] >= 2 && datahub.UnitCounter[tmp_combinefuntion.A] >= 1 && datahub.UnitCounter[tmp_combinefuntion.C] >= 1 && datahub.UnitCounter[tmp_combinefuntion.D] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    else if (base_unit.Id == tmp_combinefuntion.C || tmp_combinefuntion.C == tmp_combinefuntion.D) {
                        if (datahub.UnitCounter[tmp_combinefuntion.C] >= 2 && datahub.UnitCounter[tmp_combinefuntion.A] >= 1 && datahub.UnitCounter[tmp_combinefuntion.B] >= 1 && datahub.UnitCounter[tmp_combinefuntion.D] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    else if (base_unit.Id == tmp_combinefuntion.D) {
                        if (datahub.UnitCounter[tmp_combinefuntion.D] >= 2 && datahub.UnitCounter[tmp_combinefuntion.B] >= 1 && datahub.UnitCounter[tmp_combinefuntion.C] >= 1 && datahub.UnitCounter[tmp_combinefuntion.A] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    else {
                        if (datahub.UnitCounter[tmp_combinefuntion.A] >= 1 && datahub.UnitCounter[tmp_combinefuntion.B] >= 1 && datahub.UnitCounter[tmp_combinefuntion.C] >= 1 && datahub.UnitCounter[tmp_combinefuntion.D] >= 1)
                            can = true;
                        else
                            can = false;
                    }
                    break;
                default:
                    break;
            }


            // ���� �����ϸ� ����
            if (can) {
                size = datahub.StageField.Count;
                // ������ �� �ʿ��� ������ ���� �� unit field���� ����
                // ���̽��� UnitCounter�� ����
                datahub.UnitCounter[base_id]-=1;

                // �ʿ��� ��� A�� ���� �ʵ��� ���� ��ȣ�� ���� �� ���� ã��
                // A�� ��� ���� �ݵ�� �����ϹǷ� �ٷ� ����
                // ���� ��ȣ && Ŭ�� ��ġ�� �ѱ��
                
                if (base_id == tmp_combinefuntion.A) {

                    for (int i = 1; i < size; i++) {
                        GameObject search_field = datahub.StageField[i] as GameObject;
                        if (i != datahub.CombineWaitingPos && tmp_combinefuntion.A == search_field.GetComponent<Field>().UnitId) {
                            // unit counter���� ����
                            datahub.UnitCounter[tmp_combinefuntion.A] -= 1;
                            // �ʿ� ����̹Ƿ� 0���� ����
                            search_field.GetComponent<Field>().UnitId = 0;
                            search_field.GetComponent<UnitAttack>().Id = 0;
                            search_field.GetComponent<UnitAttack>().StopShot();
                            //search_field.GetComponent<UnitAttack>().enabled = false;
                            // ���� ���� Ȯ��
                            datahub.LeftStageField++;
                            UnitFieldChange(search_field.transform.position, 0);
                            break;
                        }
                    }
                }
                // ���� �ٸ� ����� �ٷ� ã��
                else {
                    for (int i = 1; i < size; i++) {
                        GameObject search_field = datahub.StageField[i] as GameObject;
                        if (search_field.GetComponent<Field>().UnitId == tmp_combinefuntion.A) {
                            // unit counter���� ����
                            datahub.UnitCounter[tmp_combinefuntion.A] -= 1;
                            search_field.GetComponent<Field>().UnitId = 0;
                            search_field.GetComponent<UnitAttack>().Id = 0;
                            search_field.GetComponent<UnitAttack>().StopShot();
                            //search_field.GetComponent<UnitAttack>().enabled = false;
                            // ���� ���� Ȯ��
                            datahub.LeftStageField++;
                            UnitFieldChange(search_field.transform.position, 0);
                            break;
                        }
                    }
                }

                // ���������� ��ȯ�ؾ� ������ �ɸ��� ����
                if (tmp_combinefuntion.B > 0) {
                    // B ã�� �����
                    for (int i = 1; i < size; i++) {
                        GameObject search_field = datahub.StageField[i] as GameObject;
                        int field_id = search_field.GetComponent<Field>().UnitId;
                        if (i != datahub.CombineWaitingPos && field_id == tmp_combinefuntion.B) {
                            // unit counter���� ����
                            datahub.UnitCounter[tmp_combinefuntion.B] -= 1;
                            search_field.GetComponent<Field>().UnitId = 0;
                            search_field.GetComponent<UnitAttack>().Id = 0;
                            search_field.GetComponent<UnitAttack>().StopShot();
                            //search_field.GetComponent<UnitAttack>().enabled = false;
                            // ���� ���� Ȯ��
                            datahub.LeftStageField++;
                            UnitFieldChange(search_field.transform.position, 0);
                            break;
                        }
                    }
                    if (tmp_combinefuntion.C > 0) {
                        // C ã�� �����
                        for (int i = 1; i < size; i++) {
                            GameObject search_field = datahub.StageField[i] as GameObject;
                            int field_id = search_field.GetComponent<Field>().UnitId;
                            if (i != datahub.CombineWaitingPos && field_id == tmp_combinefuntion.C) {
                                // unit counter���� ����
                                datahub.UnitCounter[tmp_combinefuntion.C] -= 1;
                                search_field.GetComponent<Field>().UnitId = 0;
                                search_field.GetComponent<UnitAttack>().Id = 0;
                                search_field.GetComponent<UnitAttack>().StopShot();
                                //search_field.GetComponent<UnitAttack>().enabled = false;
                                // ���� ���� Ȯ��
                                datahub.LeftStageField++;
                                UnitFieldChange(search_field.transform.position, 0);
                                break;
                            }
                        }

                        if (tmp_combinefuntion.D > 0) {
                            // D ã�� �����
                            for (int i = 1; i < size; i++) {
                                GameObject search_field = datahub.StageField[i] as GameObject;
                                int field_id = search_field.GetComponent<Field>().UnitId;
                                if (i != datahub.CombineWaitingPos && field_id == tmp_combinefuntion.D) {
                                    // unit counter���� ����
                                    datahub.UnitCounter[tmp_combinefuntion.D] -= 1;
                                    search_field.GetComponent<Field>().UnitId = 0;
                                    search_field.GetComponent<UnitAttack>().Id = 0;
                                    search_field.GetComponent<UnitAttack>().StopShot();
                                    //search_field.GetComponent<UnitAttack>().enabled = false;
                                    // ���� ���� Ȯ��
                                    datahub.LeftStageField++;
                                    UnitFieldChange(search_field.transform.position, 0);
                                    break;
                                }
                            }
                        }

                    }
                }

                

              

                // ��� ���Ű� �Ϸ�Ǿ����Ƿ� Ŭ�� ��ġ�� ������ ��� �������� ����
                GameObject now_select_field = datahub.StageField[datahub.CombineWaitingPos] as GameObject;
                now_select_field.GetComponent<Field>().UnitId = tmp_combinefuntion.Result;
                now_select_field.GetComponent<UnitAttack>().Id = tmp_combinefuntion.Result;

                // ��� ���� ī��Ʈ ����
                datahub.UnitCounter[tmp_combinefuntion.Result]++;

                // tmp�� ����� ��޿� ���� ���� ����
                var unit = datahub.Unit_dic[tmp_combinefuntion.Result] as Unit;
                if (unit.Grade.Equals("A") || unit.Grade.Equals("S")) {
                    achieve_observer.CombineQuestCheck(unit.Grade);
                }

                // ���ս� �ʵ带 �ʱ�ȭ
                UnitClickObserver.Instance.CleanField();

                // ���� ������ ���������ִٸ� ��Ȱ��
                if (datahub.IsShowUnitCount) {
                    UnitCounterPool.Instance.ShowUnitCount();
                }
            }

            // ���� �Ұ����ϸ� ī�带 ���� ����Ʈ�� �Ѱ� ����
            else {
                AnnounceControll.Instance.AnnounceOn(1);
            }
        }

        /// <summary>
        /// ���� ���Ḧ Ȯ���ϴ� �Լ�
        /// </summary>
        /// <param name="stage_number">���� �������� ��ȣ</param>
        /// <param name="now_enemy_round">����� ���� ��ȣ</param>
        /// <returns>
        /// 0 : Enemy ���� ����
        /// 1 : Enemy ����
        /// 2 : ���� �Ϸ�
        /// </returns>
        public static int EndRoundChecker(int now_enemy_round) {

            int end_round = datahub.EndRound;
            int end_boss_round = end_round - 1;
            //Debug.Log(end_round + " ?? " + end_boss_round);

            if (now_enemy_round >= end_round) {
                return 2;
            }

            if (now_enemy_round >= end_boss_round) {
                // spawn�� �����ؾ���
                // enemy�� �˻��ؼ� �ƹ��͵� �������� �ʴٸ� ���� ����
                var enemies = GameObject.FindGameObjectsWithTag("Enemy");
                if (enemies.Length <= 0 && datahub.KillLastBoss) {
                    return 2;
                }
                
                return 0;
            }

            // 5�� ��� ���忡 enemies�� ������ ��������� ���� ����
            if (now_enemy_round % 5 == 0 && now_enemy_round % 10 != 0) {
                var enemies = GameObject.FindGameObjectsWithTag("Enemy");
                foreach(var enemy in enemies) {
                    if (enemy.name.Equals("enemy_boss")) {
                        return 2;
                    }
                }
            }

            // �⺻�����δ� ���带 �����ؾ��ϹǷ� 1 ��ȯ
            return 1;
        }

        /// <summary>
        /// ���� ���� ��ŭ ������ ������ �̾� �ִ� �Լ�
        /// </summary>
        /// <param name="rank"> ���� ���</param>
        /// <param name="max"> ���� ����</param>
        /// <returns></returns>
        public static void SelectRecivePiece(int rank, int max) {

            int piece_name, a, b;

            switch (rank) {
                // E
                case 1:
                    a = E_start; b = E_end_1;
                    break;

                // D
                case 2:
                    a = D_start; b = D_end_1;
                    break;

                // C
                case 3:
                    a = C_start; b = C_end_1;
                    break;

                // B
                case 4:
                    a = B_start; b = B_end_1;
                    break;

                // A
                case 5:
                    a = A_start; b = A_end_1;
                    break;

                // S
                case 6:
                    a = S_start; b = S_end_1;
                    break;
                default:
                    a = 0; b = 1;
                    break;
            }

            for (int i = 0; i < max; i++) {
                //int dif = b - a;
                piece_name = Random.Range(a, b);
                datahub.UnitCounter[piece_name]++;
            }

        }

        /// <summary>
        /// ������ ���� ���ݷ��� ����Ͽ� return �ϴ� �Լ�
        /// </summary>
        /// <param name="unit_id"></param>
        /// <returns></returns>
        public static int GetResultAttack(int unit_id) {

            Unit unit = datahub.Unit_dic[unit_id] as Unit;

            return unit.Grade switch {
                "E" => unit.Attack + (unit.UpgradeValue * unit.UpgradeFigures) + datahub.UpgradeValueE * 2,
                "D" => unit.Attack + (unit.UpgradeValue * unit.UpgradeFigures) + datahub.UpgradeValueD * 2,
                "C" => unit.Attack + (unit.UpgradeValue * unit.UpgradeFigures) + datahub.UpgradeValueC * 2,
                "B" => unit.Attack + (unit.UpgradeValue * unit.UpgradeFigures) + datahub.UpgradeValueB * 2,
                "A" => unit.Attack + (unit.UpgradeValue * unit.UpgradeFigures) + datahub.UpgradeValueA * 2,
                "S" => unit.Attack + (unit.UpgradeValue * unit.UpgradeFigures) + datahub.UpgradeValueS * 2,
                _ => 0
            };
        }

        /// <summary>
        /// ������ ����� �޾ƿ��� �Լ�
        /// </summary>
        /// <param name="id">unit id</param>
        /// <returns>E ~ S</returns>
        public static string GetUnitGrade(int id) {

            return (datahub.Unit_dic[id]).Grade;
        }

        public static void MergeSort(int[] arr, int start, int end) {

            if (start >= end)
                return;

            int mid = (start + end) / 2;
            MergeSort(arr, start, mid);
            MergeSort(arr, mid + 1, end);
            Merge(arr, start, mid, end);
        }

        private static void Merge(int[] arr, int start, int mid, int end) {
            int a = start;
            int b = mid + 1;
            int c = start;

            int[] tmp = new int[arr.Length];
            // ���������� ������ ���������� ���ϸ� �����ͺ��� ����
            while (a <= mid && b <= end) {
                tmp[c++] = arr[a] <= arr[b] ? arr[a++] : arr[b++];
            }

            // �����ִ� ��� ������� �ٽ� �ֱ�
            // �Ŀ����� Ȯ�� -> ������ �� ���� ��츦 ���� �־����Ƿ� 
            // ������ �������� �Ŀ����� ū�� -> �ݵ�� ���� �Ŀ��� ���� �������� ����
            while (b <= end) {
                tmp[c++] = arr[b++];
            }
            while (a <= mid) {
                tmp[c++] = arr[a++];
            }

            // a�� ���Ļ��·� �ű��
            // �������� start�� end������
            for (int i = start; i <= end; i++) {
                arr[i] = tmp[i];
            }

        }

    }
}