using UnityEngine;
using ShapeDefenseSpace;
using static ShapeDefenseSpace.GameData;
using Unity.VisualScripting;
public class User
{
    #region VALUE
    private string nickname;            // �̸�
    private int dot;                    // ���(��)
    private int level;                  // ����
    private int experience;             // ����ġ
    private int need_experience;        // �� ���� �ִ� ����ġ ��
    private int stamina;                // ����
    private int max_stamina;            // �ִ� ������
    private int change_nickname_recode; // �̸� ���� Ƚ��
    private int skill_point;            // ���� ��ų ����Ʈ(����� ���� ����Ʈ)
    private int max_skill_point;        // �ִ� ��ų ����Ʈ
    private int status_attack_level;        // �߰� ���ݷ� ���� ����
    private int status_attackspeed_level;   // �߰� ���ݼӵ� ���� ����
    private int status_start_dot_level;     // ���� ��ȭ �߰� ����
    private int status_gain_dot_level;      // �� óġ�� ȹ�� ��ȭ ���� ����
    private int status_clear_dot_level;     // ���� Ŭ����� ȹ�� ��� ���� ����

    #endregion

    #region property
    public string Nickname { get { return nickname; } set {  nickname = value; } }
    public int Dot { get { return dot; } set { dot = value; } }
    public int Level { get { return level; } set { level = value; } }
    public int NeedExperience { get { return need_experience; } set { need_experience = value; } }
    public int Stamina { 
        get {  return stamina; } 
        set {  
            stamina = value;
            if (datahub.DBConnectEnd) {
                stamina_observer.StartCharge();
            }
        } 
    }
    public int MaxStamina { get { return max_stamina; } set {  max_stamina = value; } }
    public int ChangeNickNameRecode { get { return change_nickname_recode; } set { change_nickname_recode = value; } }
    public int SkillPoint { get { return skill_point; } set { skill_point = value; } }
    public int MaxSkillPoint { get { return max_skill_point; } set { max_skill_point = value; } }
    public int StatusAttackLevel { get { return status_attack_level; } set {  status_attack_level = value; } }
    public int StatusAttackSpeedLevel { get { return status_attackspeed_level; } set { status_attackspeed_level = value; } }
    public int StatusStartDotLevel { get { return status_start_dot_level; } set { status_start_dot_level = value; } }
    public int StatusGainDotLevel { get { return status_gain_dot_level; } set { status_gain_dot_level = value; } }
    public int StatusClearDotLevel { get { return status_clear_dot_level; } set { status_clear_dot_level = value; } }

    public int Experience {
        get { return experience; }
        set {
            experience = value;
            LevelUpCheck();
        }
    }
    #endregion

    private void LevelUpCheck() {
        string query;
        
        // ���� �� �� �� �ִ��� Ȯ��
        if (experience > 0 && experience >= need_experience && need_experience > 0) {
            level++;
            experience -= need_experience;
            need_experience += 100;

            // max stamina
            max_stamina += 2;

            // stamia check
            if ( stamina < max_stamina ) {
                stamina = max_stamina;
            }

            max_skill_point += 1;
            skill_point += 1;

            // db ���ε�
            // level, stamina, exp, max_stamina, skillpoint, max_skill_point
            query = UtilityHub.query_builder.Append("UPDATE user SET level=")
                                            .Append(level)
                                            .Append(", stamina=")
                                            .Append(stamina)
                                            .Append(", max_stamina=")
                                            .Append(max_stamina)
                                            .Append(", experience=")
                                            .Append(experience)
                                            .Append(", max_exp=")
                                            .Append(need_experience)
                                            .Append(", skill_point=")
                                            .Append(skill_point)
                                            .Append(", max_skill_point=")
                                            .Append(max_skill_point)
                                            .ToString();
            UtilityHub.query_builder.Clear();
            modifyDB.ControllDB(query, "user");

            if (!datahub.Gaming) {
                // stat effect ����
                StatEffectObserver.Instance.EffectObserve();
                // stamina ����
                StaminaShow.Instance.ReShow();
            }
        }
    }


    public void AllSkillUpdate() {
        string query = UtilityHub.query_builder.Append("UPDATE user SET skill_point=")
                                               .Append(skill_point)
                                               .Append(", max_skill_point=")
                                               .Append(max_skill_point)
                                               .Append(", status_attack_level=")
                                               .Append(status_attack_level)
                                               .Append(", status_attackspeed_level=")
                                               .Append(status_attackspeed_level)
                                               .Append(", status_start_dot_level=")
                                               .Append(status_start_dot_level)
                                               .Append(", status_gain_dot_level=")
                                               .Append(status_gain_dot_level)
                                               .Append(", status_clear_dot_level=")
                                               .Append(status_clear_dot_level)
                                               .ToString();
        UtilityHub.query_builder.Clear();
        modifyDB.ControllDB(query, "user");
    }

    public void SkillInit() {
        status_attackspeed_level = 0;
        status_attack_level = 0;
        status_clear_dot_level = 0;
        status_gain_dot_level = 0;
        status_start_dot_level = 0;
        skill_point = max_skill_point;

        AllSkillUpdate();
    }

    private void MaxStaminaInit() {
        string query = UtilityHub.query_builder.Append("UPDATE user SET max_stamina=")
                                               .Append(max_stamina)
                                               .ToString();
        UtilityHub.query_builder.Clear();
        modifyDB.ControllDB(query, "user");
    }

    // ���� ������ �°� ��ų����Ʈ�� �����Ǿ��ִ��� Ȯ��
    public void UserCorrectCheck() {
        //stamina check
        int max_stamina_val = 20 + ((level - 1) * 2);
        if(max_stamina != max_stamina_val) {
            max_stamina = max_stamina_val;
            MaxStaminaInit();
        }

        // skill check
        // ���� ���� -1��ŭ max skill point�� ���ٸ� ����
        int must_need_val = level - 1;
        if(must_need_val != max_skill_point) {
            max_skill_point = must_need_val;
            skill_point = max_skill_point;
            //Debug.Log(max_skill_point);
            SkillInit();
            return;
        }

        if (max_skill_point == 0 && level >= 2) {
            max_skill_point = level - 1;
            skill_point = max_skill_point;
            SkillInit();
            return;
        }

        datahub.UserConnectEnd = true;
    }
}
