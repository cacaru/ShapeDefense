using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using static ShapeDefenseSpace.GameData;

public class HeaderSetting : Singleton<HeaderSetting>
{
    // header ���� ��ü ����
    [SerializeField] private GameObject Header;

    // Start is called before the first frame update
    void Start()
    {
        Header.transform.Find("EXP").gameObject.GetComponent<Slider>().interactable = false;
        HeaderSet();
        // ȭ���� ��ȯ�� �� ���� ����
        SceneManager.sceneLoaded += HeaderSetBox;
    }

    private void HeaderSetBox(Scene scene, LoadSceneMode mode) {
        // ���� ���� Map�� ���ԵǸ� ������Ʈ ����
        if (scene.name.Contains("Map") || scene.name.Equals("UnitDetailScene")) {
            gameObject.SetActive(false);
        }
        else {
            gameObject.SetActive(true);
            HeaderSet();
        }
        
    }

    public void HeaderSet() {
        // data ����
        // �̸�
        Header.transform.Find("Name").gameObject.GetComponent<TMP_Text>().text = datahub.User.Nickname.ToString();
        // ����
        Header.transform.Find("Level").gameObject.GetComponent<TMP_Text>().text = datahub.User.Level.ToString();
        // ���
        Header.transform.Find("Gold").gameObject.GetComponent<TMP_Text>().text = datahub.User.Dot.ToString();
        // ����ġ��
        float exp = datahub.User.Experience > 0 ? (float)datahub.User.Experience / datahub.User.NeedExperience : 0;
        Header.transform.Find("EXP").gameObject.GetComponent<Slider>().value = exp;
        Header.transform.Find("EXP_Text").gameObject.GetComponent<TMP_Text>().text = (exp * 100).ToString();
    }
}
