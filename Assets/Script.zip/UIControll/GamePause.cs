using UnityEngine;
using static ShapeDefenseSpace.GameData;

public class GamePause : Singleton<GamePause>
{

    private void Update() {
        // �ڷΰ��� ��ư ������
        if (Input.GetKey(KeyCode.Escape)) {
            // ingame �̸� pause
            if (datahub.Gaming) {
                GameObject.Find("Enemy").GetComponent<RoundProgress>().Pause();
                GameObject.Find("SettingControll").GetComponent<SettingPageControll>().SettingOnClick();
            }
            // �ƴϸ� ���� ���� announce
            else {
                GameObject.Find("Canvas").transform.Find("EndAnnounce").gameObject.SetActive(true);
            }
        }


    }

    public void EnemyPauseSetting(bool value) {

        if (value) {
            datahub.Pause = false;
        }
        else {
            datahub.Pause = true;
        }
    }
}
