using TMPro;
using UnityEngine;
using System.Text.RegularExpressions;
using ShapeDefenseSpace;
using static ShapeDefenseSpace.GameData;
public class NickNameSetting : MonoBehaviour
{
    [SerializeField] private TMP_Text Nick_Name;
    [SerializeField] private GameObject Change_Field;
    [SerializeField] private TMP_InputField Nick_Name_Input;

    [SerializeField] private TMP_Text Need_Gold_Text;

    [SerializeField] private TMP_Text Change_Field_Now_NickName_Text;
    [SerializeField] private TMP_Text Modal_Change_NickName_Text;

    [SerializeField] private GameObject Announce_Modal;
    [SerializeField] private TMP_Text Announce_Text;
    [SerializeField] private GameObject Check_Modal;

    private string query;

    private readonly Regex nick_checker_regex = new Regex(@"[^a-zA-Z0-9��-����-�R]+");
    private readonly string STRING_UNCHECK = "�ѱ�, ����, ���ڸ�\r\n�Է� �����մϴ�.";
    private readonly string STRING_LENGTH = "12�� ���Ϸθ� ���� �����մϴ�.";
    private readonly string STRING_GOLDLESS = "��尡 �����մϴ�.";


    private void ShowNickName() {
        Nick_Name.text = datahub.User.Nickname;
        // header�� �߰� ����
        UtilityHub.PageHeaderSetting();
    }

    /// <summary>
    /// ���� �������� �����ϱ�
    /// </summary>
    public void ChangeNickNameClick() {
        // ���� �̸� �޾ƿ���
        Change_Field_Now_NickName_Text.text = datahub.User.Nickname;

        // �ʿ� ��� �м�
        int need_gold = datahub.User.ChangeNickNameRecode * 500;
        //Debug.Log("need-Gold  > " + need_gold);
        Need_Gold_Text.text = need_gold.ToString();

        Change_Field.SetActive(true);
    }

    /// <summary>
    /// ����Ȯ�� �ȳ�â ����
    /// </summary>
    public void CheckNickModal() {
        // �̸� �˻�
        // �г��� �˻�
        // Ư������ �ȵǰ� ����, �ѱ�, ���ڸ�, 12���� �̳��� �˻�
        var check_nick_result = nick_checker_regex.IsMatch(Nick_Name_Input.text);
        //Debug.Log("check_nick_isnt_possible > " + check_nick_result);
        if (check_nick_result) {
           // Debug.Log("Dont Match");
            // announce
            Announce_Text.text = STRING_UNCHECK;
            Announce_Modal.SetActive(true);
            return;
        }
        //Debug.Log("nickname string length > " + Nick_Name_Input.text.Length);
        // �̸� ���� �˻�
        if (Nick_Name_Input.text.Length > 12 || Nick_Name_Input.text.Length <= 0) {
           // Debug.Log("���� �ʰ�");
            Announce_Text.text = STRING_LENGTH;
            Announce_Modal.SetActive(true);
            return;
        }

        // �̸� ����
        Modal_Change_NickName_Text.text = Nick_Name_Input.text;
        Check_Modal.SetActive(true);
    }

    /// <summary>
    /// ����� �̸� ����
    /// </summary>
    public void ChangeNickName() {
        bool use_gold = false;
        // ���� ���� 
        // ���� 1ȸ ����
        // ���� ����ø��� 500 ��� �ʿ�
        // ����
        if(datahub.User.ChangeNickNameRecode != 0 && datahub.User.Dot < 500) {
            // announce
            // ��� ���� �ȳ�
            Announce_Text.text = STRING_GOLDLESS;
            Announce_Modal.SetActive(true);
            return;
        }
        else if(datahub.User.ChangeNickNameRecode != 0 && datahub.User.Dot >= 500) {
            use_gold = true;
        }

        // ����Ǿ����� ����
        if(use_gold) {
            datahub.User.Dot -= 500;  
        }
        datahub.User.Nickname = Nick_Name_Input.text;
        datahub.User.ChangeNickNameRecode += 1;
        
        // dot, nickname, changeNickNameRecode ���ε�
        query = UtilityHub.query_builder.Append("UPDATE user SET dot=")
                                        .Append(datahub.User.Dot)
                                        .Append(", nickname='")
                                        .Append(datahub.User.Nickname)
                                        .Append("', nickname_change_recode=")
                                        .Append(datahub.User.ChangeNickNameRecode)
                                        .ToString();
        UtilityHub.query_builder.Clear();
        modifyDB.ControllDB(query, "user");

        /*
        query = UtilityHub.query_builder.Append("UPDATE user SET nickname='")
                                        .Append(datahub.User.Nickname)
                                        .Append("'")
                                        .ToString();
        UtilityHub.query_builder.Clear();
        modifyDB.ControllDB(query, "user");

        query = UtilityHub.query_builder.Append("UPDATE user SET nickname_change_recode=")
                                        .Append(datahub.User.ChangeNickNameRecode)
                                        .ToString();
        UtilityHub.query_builder.Clear();
        //Debug.Log(query);
        modifyDB.ControllDB(query, "user");
        */

        Check_Modal.SetActive(false);
        Change_Field.SetActive(false);
        ShowNickName();
    }

    /// <summary>
    /// ���� Ȯ�ο��� ��� -> modal�� �ݱ�
    /// </summary>
    public void CheckCancel() {
        Check_Modal.SetActive(false);
    }

    /// <summary>
    /// �Ұ� �ȳ�â �ݱ�
    /// </summary>
    public void AnnounceCancel() {
        Announce_Modal.SetActive(false);
    }
    
    /// <summary>
    /// �̸� ���� ����ϱ�
    /// </summary>
    public void ChangeCancel() {
        Check_Modal.SetActive(false);
        Nick_Name_Input.text = "";
        Change_Field.SetActive(false);
    }
}
