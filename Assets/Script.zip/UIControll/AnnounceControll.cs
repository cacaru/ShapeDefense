using System.Collections;
using TMPro;
using UnityEngine;
using ShapeDefenseSpace;
using static ShapeDefenseSpace.PublicData;
using static ShapeDefenseSpace.GameData;

public class AnnounceControll : SceneSingleton<AnnounceControll>
{
    [SerializeField] private GameObject AnnouncePanel;
    [SerializeField] private GameObject CombineConfirm;
    [SerializeField] private GameObject RollConfirm;
    [SerializeField] private GameObject TypeRollConfirm;
    [SerializeField] private GameObject ImpossibleAnnounce;

    private Animator animator;

    public int CombineID = 0;
    public int WaitingPos = 0;

    private readonly string CannotCombineText = "��ᰡ �����Ͽ� \r\n������ �� �����ϴ�.";
    private readonly string CannotSummonText = "������ �����Ͽ�\r\n������ ��ȯ�� �� �����ϴ�.";
    // Start is called before the first frame update
    void Start()
    {
        animator = AnnouncePanel.GetComponent<Animator>();
    }

    /// <summary>
    /// �ȳ�â ����
    /// </summary>
    /// <param name="type">
    ///     1 > ���� �Ұ� �ȳ� 
    ///     2 > ���� Ȯ��â 
    ///     3 > ��ȯ �Ұ� �ȳ�
    ///     4 > ��ȯ �ȳ�
    ///     5 > ���� Ÿ�� ��ȯ �ȳ�
    /// </param>
    /// 
    public void AnnounceOn(int type) {
        switch (type) {
            case 1:
                ImpossibleAnnounce.transform.Find("Announce").gameObject.GetComponent<TMP_Text>().text = CannotCombineText;
                ImpossibleAnnounce.SetActive(true);
                // 1�ʵ� �ȳ�â ����
                StartCoroutine(AutoClose());
                break;

            case 2:
                UnitClickObserver.Instance.Click_Off();
                CombineConfirm.SetActive(true);
                break;

            case 3:
                ImpossibleAnnounce.transform.Find("Announce").gameObject.GetComponent<TMP_Text>().text = CannotSummonText;
                ImpossibleAnnounce.SetActive(true);
                // 1�ʵ� �ȳ�â ����
                StartCoroutine(AutoClose());
                break;
            case 4:
                UnitClickObserver.Instance.Click_Off();
                RollConfirm.SetActive(true);
                break;

            case 5:
                UnitClickObserver.Instance.Click_Off();
                TypeRollConfirm.SetActive(true);
                break;
        }
        animator.SetBool(ANI_ACTIVATE, true);
    }

    public void AnnounceOff() {
        ImpossibleAnnounce.SetActive(false);
        CombineConfirm.SetActive(false);
        animator.SetBool(ANI_ACTIVATE, false);
    }

    IEnumerator AutoClose() {
        yield return wfs_1_5;
        AnnounceOff();
    }

    // combine controll
    // ����Ȯ�� �̺�Ʈ
    public void CombineStart() {
        CombineConfirm.SetActive(false);
        UnitClickObserver.Instance.Click_On();
        animator.SetBool(ANI_ACTIVATE, false);
        datahub.CombineWaitingPos = WaitingPos;
        UtilityHub.CombineCheck(CombineID);
    }

    public void CombineCancel() {
        CombineConfirm.SetActive(false);
        UnitClickObserver.Instance.Click_On();
        animator.SetBool(ANI_ACTIVATE, false);
    }

    // reroll cofirm
    public void RollStart() {
        RollConfirm.SetActive(false);
        UnitClickObserver.Instance.Click_On();
        animator.SetBool(ANI_ACTIVATE, false);

        // Roll 
        datahub.ItemRollActive = true;
        ItemReroll.Instance.Reroll();
    }

    public void RollCancel() {
        datahub.ItemRollActive = false;
        RollConfirm.SetActive(false);
        UnitClickObserver.Instance.Click_On();
        animator.SetBool(ANI_ACTIVATE, false);
    }

    // reroll cofirm
    public void TypeRollStart() {
        TypeRollConfirm.SetActive(false);
        UnitClickObserver.Instance.Click_On();
        animator.SetBool(ANI_ACTIVATE, false);

        // Roll
        TypeReroll.Instance.Reroll();
    }

    public void TypeRollCancel() {
        TypeRollConfirm.SetActive(false);
        UnitClickObserver.Instance.Click_On();
        animator.SetBool(ANI_ACTIVATE, false);
    }

}
