using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// ���� ���� �޾� slider�� ���� �����ϴ� �Լ�
/// </summary>
public class AchievementSliderChecker : MonoBehaviour
{
    // slider
    [SerializeField] private GameObject Slider;

    // �ش� ���� �޼� �ʿ䰪
    private int need_val = 0;
    // ���� ��
    private int now_val = 0;

    private float result_val;

    public void ValueSet() {
        Slider.GetComponent<Slider>().value = result_val;
    }

    public int NeedVal { 
        set { 
            need_val = value; 
            if (need_val > 0 && now_val > 0) {
                result_val = (float)now_val / need_val;
            }
            else if(need_val == 0 && now_val == 0) {
                result_val = 0;
            }
            ValueSet();
        } 
    }
    public int NowVal { 
        set { 
            now_val = value;
            if (need_val > 0 && now_val > 0) {
                result_val = (float)now_val / need_val;
            }
            else if (need_val == 0 && now_val == 0) {
                result_val = 0;
            }
            ValueSet();
        } 
    }
}
