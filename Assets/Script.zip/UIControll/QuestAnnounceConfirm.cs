using System.Collections;
using TMPro;
using UnityEngine;
using ShapeDefenseSpace;
/// <summary>
/// ���� �ޱ� ��� �޾ư���
/// </summary>
public class QuestAnnounceConfirm : MonoBehaviour
{
    [SerializeField] private GameObject QuestController;

    [SerializeField] private TMP_Text ConfirmAnnounceText;
    [SerializeField] private GameObject ConfirmBtn;

    private readonly string confirmText = "Ȯ����";

    // Ȯ��â Ȯ��
    public void RecieveConfirm() {
        // text ����
        ConfirmAnnounceText.text = confirmText;

        // ��� â�� ���ε�
        QuestController.GetComponent<DailyQuestControll>().Show();
        QuestController.GetComponent<AchievementControll>().Show();
        QuestController.GetComponent<WeeklyQuestControll>().Show();

        // ani reload
        QuestReciveObserver.Instance.SetAni();

        // unit upgrade check reload
        UnitUpgradeObserver.Instance.SetAni();
        UIUnitPageSetting.Instance.CheckUnitLevel();

        // ��� ������ ���� header reload
        UtilityHub.PageHeaderSetting();

        ConfirmBtn.SetActive(false);
        gameObject.SetActive(false);
    }

}