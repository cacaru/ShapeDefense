using System.Collections;
using UnityEngine;
using static ShapeDefenseSpace.GameData;

public class FirstSceneObserver : MonoBehaviour
{
    private bool is_active = false;
    private void Update() {
        if (datahub.QuestResetChecker) {
            datahub.QuestResetChecker = false;
            achieve_observer.AttendanseCheck();
           
            gameObject.GetComponent<DailyQuestControll>().PageReset(); 
            gameObject.GetComponent<WeeklyQuestControll>().PageReset();
            gameObject.GetComponent<DailyQuestControll>().Show();
            gameObject.GetComponent<WeeklyQuestControll>().Show();
        }

        if (datahub.DBConnectEnd && !is_active) {

            StatEffectObserver.Instance.EffectObserve();
            UIUnitPageSetting.Instance.CheckUnitLevel();
            UnitUpgradeObserver.Instance.SetAni();
            QuestReciveObserver.Instance.SetAni();
            StaminaShow.Instance.enabled = true;
            stamina_observer.enabled = true;

            // ���� �ε� ���� �� ��ũ��Ʈ�� �ʿ� �����Ƿ� �ٷ� ����
            gameObject.GetComponent<FirstSceneObserver>().enabled = false;
        }
    }
}