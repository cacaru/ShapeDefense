using UnityEngine;
using UnityEngine.EventSystems;
using static ShapeDefenseSpace.PublicData;
using static ShapeDefenseSpace.GameData;

/// <summary>
/// ���� �� ���� �������� �̵���Ű�� �Լ�
/// </summary>
/// 
public class UnitDetailMove : MonoBehaviour, IPointerClickHandler {

    public void OnPointerClick(PointerEventData eventData) {
        GameObject now = eventData.pointerCurrentRaycast.gameObject;
        
        if (now != null) {
            string name = now.name;
            if ( name.Contains("_") ) {
                datahub.UnitidWithPage = int.Parse(name.Split("_")[0]);
                
                if ( datahub.UnitidWithPage > 1000 && datahub.UnitidWithPage < 6999) {
                    // ���� ������ ǥ�� �������� �̵�
                    //SceneManager.LoadScene("UnitDetailScene");
                    // ���� ������ â ����
                    UnitDetailPageSetting.Instance.SettingPage();

                    // animate activate
                    UnitDetailPageSetting.Instance.gameObject.GetComponent<Animator>().SetBool(ANI_ACTIVATE, true);
                    gameObject.GetComponent<Animator>().SetBool("On", true);
                }
            }

        }
    }
}
