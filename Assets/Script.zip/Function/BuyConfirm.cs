using TMPro;
using UnityEngine;
using UnityEngine.UI;
using ShapeDefenseSpace;
using static ShapeDefenseSpace.GameData;
using static ShapeDefenseSpace.PublicData;
using System.Collections.Generic;

public class BuyConfirm : SceneSingleton<BuyConfirm> {
    [SerializeField]
    private GameObject Popup;
    [SerializeField]
    private GameObject Confirm;
    [SerializeField]
    private GameObject Content;
    [SerializeField]
    private GameObject CannotBuyAnnounce;
    [SerializeField]
    private GameObject StaminaConfirmField;

    // ���� ����
    public void ChestBuy() {

        // ��޿� ���� Ȯ���� ���� ����
        string key = Popup.GetComponent<Chest>().Id;

        // ���� ���� ���� �� �� �ִ��� Ȯ��
        int need_gold = key switch {
            "no" => 100,
            "ad" => 500,
            "lu" => 1000,
            "li" => 3000,
            "cu" => 5000,
            _ => 1000000,
        };

        // �� �� ������ ��� ���� �ȳ��� �����ϰ� ����
        if (datahub.User.Dot < need_gold) {
            CannotBuyAnnounce.SetActive(true);
            Popup.GetComponent<Chest>().Reset();
            Popup.SetActive(false);
            return;
        }
        // ���� 
        datahub.User.Dot -= need_gold;
        string query = UtilityHub.query_builder.Append("UPDATE user SET dot=")
                                                      .Append(datahub.User.Dot)
                                                      .ToString();
        UtilityHub.query_builder.Clear();
        modifyDB.ControllDB(query, "user");

        ChestCheck();

        // header reload
        UtilityHub.PageHeaderSetting();
    }

    public void ChestCheck() {
        // ��޿� ���� Ȯ���� ���� ����
        string key = Popup.GetComponent<Chest>().Id;
        string query;

        // ���� ����
        // ���� ����Ʈ �ƹ� ���� 1ȸ �����ϱ�
        int quest_val = key switch {
            "no" => 1,
            "ad" => 2,
            "lu" or "adv" => 3,
            "li" => 4,
            "cu" => 5,
            _ => 0
        };
        achieve_observer.BuyChestQuestCheck(quest_val);

        // ���� ������ ���� �غ�
        int first_quarter = Popup.GetComponent<Chest>().e;
        int second_quarter = first_quarter + Popup.GetComponent<Chest>().d;
        int third_quarter = second_quarter + Popup.GetComponent<Chest>().c;
        int foured_quarter = third_quarter + Popup.GetComponent<Chest>().b;
        int fived_quarter = foured_quarter + Popup.GetComponent<Chest>().a;
        int sixed_quarter = fived_quarter + Popup.GetComponent<Chest>().s;

        int size = key switch {
            "no" => 10,
            "ad" => 20,
            "lu" or "adv" => 30,
            "li" => 50,
            "cu" => 100,
            _ => 10
        };

        datahub.InitCounter();
        // Ȯ���� ���� ���� ����

        // ������ ���� ã��
        for (int i = 0; i < size; i++) {
            int random_number = Random.Range(0, 100); // 0~99
            // e
            if (0 <= random_number && random_number < first_quarter) {
                // 1~3
                datahub.UnitCounter[Random.Range(E_start, E_end_1)]++;
            }
            // d
            else if (first_quarter <= random_number && random_number < second_quarter) {
                // 6 ~ 8
                datahub.UnitCounter[Random.Range(D_start, D_end_1)]++;
            }
            // c
            else if (second_quarter <= random_number && random_number < third_quarter) {
                // 9 ~ 22
                datahub.UnitCounter[Random.Range(C_start, C_end_1)]++;
            }
            // b
            else if (third_quarter <= random_number && random_number < foured_quarter) {
                // 23 ~ 33
                datahub.UnitCounter[Random.Range(B_start, B_end_1)]++;
            }
            // a
            else if (foured_quarter <= random_number && random_number < fived_quarter) {
                // 34 ~ 38
                datahub.UnitCounter[Random.Range(A_start, A_end_1)]++;
            }
            // s
            else if (fived_quarter <= random_number && random_number < sixed_quarter) {
                // 39 ~ 43
                datahub.UnitCounter[Random.Range(S_start, S_end_1)]++;
            }
        }

        // popup�� ������ �ʱ�ȭ
        Popup.GetComponent<Chest>().Reset();
        Popup.transform.Find("Confirm").GetComponent<Button>().onClick.RemoveAllListeners();
        Popup.SetActive(false);

        var dic_keys = new List<int>(datahub.UnitCounter.Keys);
        int keys_size = dic_keys.Count;
        for (int i = 0; i < keys_size; i++) {
            if (datahub.UnitCounter[dic_keys[i]] > 0) {
                Unit tmp = datahub.Unit_dic[dic_keys[i]] as Unit;
                // tmp_unit �� ���� ������ �����Ͽ� field�� prefab���� ����ϱ�
                GameObject pre_unit = Instantiate(_unit_piece_obj, Content.transform.position, Content.transform.rotation);
                pre_unit.transform.SetParent(Content.transform, false);
                pre_unit.transform.Find("Grade").GetComponent<Image>().color = tmp.Grade switch {
                    "E" => color_e,
                    "D" => color_d,
                    "C" => color_c,
                    "B" => color_b,
                    "A" => color_a,
                    "S" => color_s,
                    _ => core_color
                };
                pre_unit.transform.Find("Unit").GetComponent<Image>().sprite = UtilityHub.GetSprite(tmp.Id); // Resources.Load<Sprite>(UtilityHub.GetPath(tmp.Id));
                pre_unit.transform.Find("Counter").GetComponent<TMP_Text>().text = UtilityHub.query_builder.Append("x ")
                                                                                                           .Append(datahub.UnitCounter[dic_keys[i]].ToString())
                                                                                                           .ToString();
                UtilityHub.query_builder.Clear();

                // tmp_unit �� ���� �� unit�� �ݿ�
                tmp.Piece += datahub.UnitCounter[dic_keys[i]];

                // unit �� db�� modify
                query = UtilityHub.query_builder.Append("UPDATE unit SET piece=")
                                                       .Append(tmp.Piece)
                                                       .Append(" WHERE id=")
                                                       .Append(tmp.Id)
                                                       .ToString();
                modifyDB.ControllDB(query, "unit");
                UtilityHub.query_builder.Clear();
            }
        }

        // ���� ��� â ���̱�
        Confirm.transform.Find("Field").gameObject.SetActive(true);
        Confirm.transform.Find("Announce").gameObject.SetActive(false);
        Confirm.GetComponent<ChestResultAnchor>().AnchorReset();
        Confirm.SetActive(true);
    }

    public void FreeChestCheck(int reward_type) {
        string now_time = System.DateTime.Now.ToString("MMddHHmmss");

        switch (reward_type) {
            case 1:
                PlayerPrefs.SetString("Adv_UnitChest_RemainTime", now_time);
                PlayerPrefs.Save();
                ChestCheck();
                datahub.AdvUnitTimerStart();
                AdvChestChecker.Instance.UnitAdvTimerShowing();
                break;
            case 2:
                PlayerPrefs.SetString("Adv_StaChest_RemainTime", now_time);
                PlayerPrefs.Save();
                AdvStaminaBuy();
                datahub.AdvStaTimerStart();
                AdvChestChecker.Instance.StaAdvTimerShowing();
                break;
        }
    }

    private void CleanResultList() {
        var list = Content.GetComponentsInChildren<Transform>();
        foreach (var item in list) {
            if (item != Content.transform) {
                Destroy(item.gameObject);
            }
        }
    }

    // ���� ���� ���
    public void ChestBuyCancel() {
        Popup.GetComponent<Chest>().Reset();
        Popup.transform.Find("Confirm").GetComponent<Button>().onClick.RemoveAllListeners();
        Popup.SetActive(false);
    }


    // ���� ���� Ȯ��
    public void ConfrimCheck() {
        // ���� ��� ������Ʈ û��
        CleanResultList();

        Confirm.transform.Find("Field").gameObject.SetActive(false);
        Confirm.transform.Find("Announce").gameObject.SetActive(false);
        Confirm.SetActive(false);
    }

    // ���¹̳� ����
    public void StaminaBuy() {
        // ��尡 ������� Ȯ��
        int need_gold = StaminaConfirmField.GetComponent<BuyStaminaData>().NeedGold;

        if (datahub.User.Dot < need_gold) {
            StaminaConfirmField.GetComponent<BuyStaminaData>().Reset();
            StaminaConfirmField.SetActive(false);
            CannotBuyAnnounce.SetActive(true);
            return;
        }

        // ������ ���¹̳� ��
        int val = StaminaConfirmField.GetComponent<BuyStaminaData>().StaminaValue;

        string result_text = UtilityHub.query_builder.Append("���� ���¹̳�\n")
                                                     .Append(datahub.User.Stamina)
                                                     .Append("\n\n���� ���� ���¹̳�\n")
                                                     .Append((datahub.User.Stamina + val))
                                                     .ToString();
        Confirm.transform.Find("Announce").GetComponent<TMP_Text>().text = result_text;
        UtilityHub.query_builder.Clear();

        // ���� â ����
        StaminaConfirmField.GetComponent<BuyStaminaData>().Reset();
        StaminaConfirmField.SetActive(false);

        // ����
        datahub.User.Stamina += val;
        datahub.User.Dot -= need_gold;
        // ���� ����
        string query = UtilityHub.query_builder.Append("UPDATE user SET stamina=")
                                               .Append(datahub.User.Stamina)
                                               .Append(", dot=")
                                               .Append(datahub.User.Dot)
                                               .ToString();
        UtilityHub.query_builder.Clear();
        modifyDB.ControllDB(query, "user");


        // ���� ��� â ���̱�
        Confirm.transform.Find("Field").gameObject.SetActive(false);
        Confirm.transform.Find("Announce").gameObject.SetActive(true);
        Confirm.GetComponent<ChestResultAnchor>().AnchorReset();
        Confirm.SetActive(true);

        // header reload
        UtilityHub.PageHeaderSetting();
    }

    // ���� ���¹̳� ����
    public void AdvStaminaBuy() {
        // ������ ���¹̳� ��
        int val = UnityEngine.Random.Range(8, 17);

        string result_text = UtilityHub.query_builder.Append("���� ���¹̳�\n")
                                                     .Append(datahub.User.Stamina)
                                                     .Append("\n\n���� ���� ���¹̳�\n")
                                                     .Append((datahub.User.Stamina + val))
                                                     .ToString();
        Confirm.transform.Find("Announce").GetComponent<TMP_Text>().text = result_text;
        UtilityHub.query_builder.Clear();

        // ���� â ����
        // popup�� ������ �ʱ�ȭ
        Popup.GetComponent<Chest>().Reset();
        Popup.SetActive(false);

        // ����
        datahub.User.Stamina += val;
        // ���� ����
        string query = UtilityHub.query_builder.Append("UPDATE user SET stamina=")
                                               .Append(datahub.User.Stamina)
                                               .Append(", dot=")
                                               .Append(datahub.User.Dot)
                                               .ToString();
        UtilityHub.query_builder.Clear();
        modifyDB.ControllDB(query, "user");


        // ���� ��� â ���̱�
        Confirm.transform.Find("Field").gameObject.SetActive(false);
        Confirm.transform.Find("Announce").gameObject.SetActive(true);
        Confirm.GetComponent<ChestResultAnchor>().AnchorReset();
        Confirm.SetActive(true);
    }


    // ���¹̳� ���� ���
    public void StaminaBuyCancel() {
        StaminaConfirmField.GetComponent<BuyStaminaData>().Reset();
        Popup.transform.Find("Confirm").GetComponent<Button>().onClick.RemoveAllListeners();
        StaminaConfirmField.SetActive(false);
    }

    // ��尡 ������� �ʴٴ� �˸��� ������ â
    public void CantBuyAnnounceCheck() {
        CannotBuyAnnounce.SetActive(false);
    }


}