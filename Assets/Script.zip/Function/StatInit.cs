using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using static ShapeDefenseSpace.GameData;

public class StatInit : MonoBehaviour
{
    [SerializeField] private GameObject Announce;

    private int need_gold = 0;
    /// <summary>
    /// ���� �ʱ�ȭ ��ư Ŭ��
    /// </summary>
    ///  ó���̶�� ��¥
    ///  2ȸ���� 500��� �ʿ�
    public void StatInitClick() {

        int init_time = PlayerPrefs.GetInt("Stat_Init_Time");
        if(init_time == 0) {
            need_gold = 0;
            Announce.transform.Find("InitField").Find("Free").gameObject.SetActive(true);
        }
        else {
            need_gold = 500;
            Announce.transform.Find("InitField").Find("Gold").gameObject.SetActive(true);
        }

        Announce.SetActive(true);
    }

    public void StatInitCancel() {
        Announce.transform.Find("InitField").Find("Free").gameObject.SetActive(false);
        Announce.transform.Find("InitField").Find("Gold").gameObject.SetActive(false);
        Announce.transform.Find("InitField").gameObject.SetActive(true);
        Announce.transform.Find("Impossible").gameObject.SetActive(false);
        need_gold = 0;

        Announce.SetActive(false);
    }

    public void StatInitActive() {
        Announce.transform.Find("InitField").gameObject.SetActive(false);
        if (datahub.User.Dot < need_gold) {
            // �Ұ�
            Announce.transform.Find("Impossible").gameObject.SetActive(true);
        }

        // �ʱ�ȭ
        datahub.User.SkillInit();
        PlayerPrefs.SetInt("Stat_Init_Time", 1);
        PlayerPrefs.Save();
        StatEffectObserver.Instance.EffectObserve();
        StatInitCancel();
    }
}
