using UnityEngine;
using UnityEngine.Tilemaps;

public abstract class EnemyMovement
{
    protected float dis;
    // �̵� ���� ����
    // vertical = true > ���� , false > ����
    // horizental = true > �� , false > ��
    public bool vertical = false, horizental = false;

    // �⺻ ��ġ
    protected Vector2 ori;
    protected Vector2 move_pos;

    // üũ�� ������
    protected RaycastHit2D hit;
    protected TileBase tile;

    protected Tilemap map;
    
    public Tilemap Map { get { return map; } set { map = value; } }
    public float Dis { get { return dis; } }
    /// <summary>
    /// �̵� ���� ��ȯ �б��� Ȯ�� �Լ�`
    /// </summary>
    protected abstract void BifurcationChecker();

    /// <summary>
    ///  �̵� ��ġ ��� �Լ�
    /// </summary>
    /// <param name="pos">���� ��ġ</param>
    /// <param name="speed">�̵� �ӵ�</param>
    /// <param name="speed_rate">�ӵ� ����</param>
    private Vector2 tmp = new(0,0);
    public virtual Vector2 MoveResult(Vector2 pos, float speed, int speed_rate) {
        // �¿� �켱 üũ
        if (vertical) {
            tmp.x = move_pos.x + dis; tmp.y = move_pos.y;
            hit = Physics2D.Raycast(tmp, Vector2.zero, 0f);
            tile = map.GetTile(map.WorldToCell(hit.point));
            //string name = tile.name;
            //Debug.Log("EnemyMove3 >> check_right > " + name);
            if (tile.name.Contains("gray")) {
                pos.x += speed * speed_rate;
                if (pos.x >= move_pos.x + dis) {
                    pos.x = move_pos.x + dis;
                    move_pos.x = pos.x;
                }
                BifurcationChecker();
                return pos;
            }

        }
        else {
            tmp.x = move_pos.x - dis; tmp.y = move_pos.y;
            hit = Physics2D.Raycast(tmp, Vector2.zero, 0f);
            tile = map.GetTile(map.WorldToCell(hit.point));
            //Debug.Log(tile.name);
            if (tile.name.Contains("gray")) {
                pos.x -= speed * speed_rate;
                if (pos.x <= move_pos.x - dis) {
                    pos.x = move_pos.x - dis;
                    move_pos.x = pos.x;
                }
                BifurcationChecker();
                return pos;
            }

        }

        // ���� �̵�
        if (horizental) {
            tmp.x = move_pos.x; tmp.y = move_pos.y + dis;
            hit = Physics2D.Raycast(tmp, Vector2.zero, 0f);
            tile = map.GetTile(map.WorldToCell(hit.point));
            //string name = tile.name;
            //Debug.Log("hit : " + hit.point + "top : " + name);
            if (tile.name.Contains("gray")) {
                pos.y += speed * speed_rate;
                if (pos.y >= move_pos.y + dis) {
                    pos.y = move_pos.y + dis;
                    move_pos.y = pos.y;
                }
                BifurcationChecker();
                return pos;
            }

        }
        else {
            tmp.x = move_pos.x; tmp.y = move_pos.y - dis;
            hit = Physics2D.Raycast(tmp, Vector2.zero, 0f);
            tile = map.GetTile(map.WorldToCell(hit.point));
            //string name = tile.name;
            if (tile.name.Contains("gray")) {
                pos.y -= speed * speed_rate;
                if (pos.y <= move_pos.y - dis) {
                    pos.y = move_pos.y - dis;
                    move_pos.y = pos.y;
                }
                BifurcationChecker();
                return pos;
            }
        }
        //Debug.Log("lost pos");
        // �ƹ� ���⵵ ã�����ߴٸ� �Ͻ�����
        return pos;
    }
}
