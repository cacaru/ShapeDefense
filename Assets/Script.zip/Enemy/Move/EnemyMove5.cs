using UnityEngine;

/// <summary>
/// �� �̵� ���� ��ũ��Ʈ 5
/// �ʿ� ���� �̵��� ������ �� �ֵ��� �����ϱ�
/// </summary>

public class EnemyMove5 : EnemyMovement {

    public EnemyMove5(Vector2 ori, Vector2 move_pos) {
        this.ori = ori;
        this.move_pos = move_pos;
        dis = 0.51f;
    }

    protected override void BifurcationChecker() {

        // �����϶� �� -> ��
        // point1 == �� -> ��
        // point2 == �� -> ��
        // point3 == �� -> ��
        // point4 == �� -> ��
        // point5 == �� -> ��
        if(ori == move_pos) {
            horizental = false;
            vertical = false;
        }

        //point1
        if(Mathf.Approximately(move_pos.x, ori.x - dis) && Mathf.Approximately(move_pos.y , ori.y - dis)) {
            vertical = true;
        }

        //point2
        if(Mathf.Approximately(move_pos.x, ori.x + dis * 6) && Mathf.Approximately(move_pos.y, ori.y - dis * 8)) {
            vertical = false;
        }

        // point3
        if(Mathf.Approximately(move_pos.x, ori.x) && Mathf.Approximately(move_pos.y, ori.y - dis * 9)) {
            horizental = true;
        }

        // point4
        if(Mathf.Approximately(move_pos.x, ori.x - dis) && Mathf.Approximately(move_pos.y, ori.y - dis * 8)) {
            vertical = true;
        }

        // point5
        if(Mathf.Approximately(move_pos.x, ori.x + dis * 6) && Mathf.Approximately(move_pos.y, ori.y - dis)) {
            vertical = false;
        }

    }

}
