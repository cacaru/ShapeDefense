using UnityEngine;
using static Unity.Burst.Intrinsics.X86.Avx;


/// <summary>
/// �� �̵� ���� ��ũ��Ʈ 7
/// �ʿ� ���� �̵��� ������ �� �ֵ��� �����ϱ�
/// </summary>

public class EnemyMove8 : EnemyMovement {

    // true -> ���� �ʵ�
    // false -> ������ �ʵ�
    private bool field_selecter;
    private bool only_horizental = false;
    private bool only_vertical = false;

    public EnemyMove8(Vector2 ori, Vector2 move_pos, bool field_selecter) {
        this.ori = ori;
        this.move_pos = move_pos;
        this.field_selecter = field_selecter;

        dis = 0.405f;
    }

    protected override void BifurcationChecker() {
        
        // �ϴ��� ��
        if (field_selecter) {
            // �⺻ ����->�Ʒ�
            if (ori == move_pos) {
                horizental = false;
                vertical = true;
            }
            // �� ��
            if(Mathf.Approximately(move_pos.x , ori.x + (dis * 12)) && Mathf.Approximately(move_pos.y, ori.y - dis * 5)) {
                horizental = true;
                vertical = false;
            }
            // ���θ� ������
            if (Mathf.Approximately(move_pos.x, ori.x + (dis * 4)) && Mathf.Approximately(move_pos.y, ori.y - dis)) {
                only_horizental = true;
                only_vertical = false;
            }
            // �� ������ ������
            if (Mathf.Approximately(move_pos.x, ori.x + (dis * 4)) && Mathf.Approximately(move_pos.y, ori.y + dis * 2)) {
                only_horizental = false;
                only_vertical = false;
            }

            // �� ��
            if (Mathf.Approximately(move_pos.x , ori.x) && Mathf.Approximately(move_pos.y , ori.y + dis * 4)) {
                horizental = false;
            }
        }

        // ����� ��
        else {
            // �� / �� 
            if (ori == move_pos) {
                horizental = true;
                vertical = true;
            }
            // �� / ��
            if (Mathf.Approximately(move_pos.x, ori.x + dis * 12) && Mathf.Approximately(move_pos.y, ori.y + dis * 5)) {
                horizental = false;
                vertical = false;
            }

            // �Ʒ��θ� ������
            if (Mathf.Approximately(move_pos.x, ori.x + (dis * 4)) && Mathf.Approximately(move_pos.y, ori.y + dis)) {
                only_horizental = true;
                only_vertical = false;
            }
            // �� �Ϸ� ������
            if (Mathf.Approximately(move_pos.x, ori.x + (dis * 4)) && Mathf.Approximately(move_pos.y, ori.y - dis * 2)) {
                only_horizental = false;
                only_vertical = false;
            }

            // �� / ��
            if (Mathf.Approximately(move_pos.x , ori.x) && Mathf.Approximately(move_pos.y, ori.y - (dis * 4))) {
                horizental = true;
                vertical = false;
            }
        }
    }

    private Vector2 tmp = new(0, 0);
    public override Vector2 MoveResult(Vector2 pos, float speed, int speed_rate) {
        // �¿� �켱 üũ
        if (vertical && !only_horizental) {
            tmp.x = move_pos.x + dis; tmp.y = move_pos.y;
            hit = Physics2D.Raycast(tmp, Vector2.zero, 0f);
            tile = map.GetTile(map.WorldToCell(hit.point));
            //string name = tile.name;
            //Debug.Log("EnemyMove3 >> check_right > " + name);
            if (tile.name.Contains("gray")) {
                pos.x += speed * speed_rate;
                if (pos.x >= move_pos.x + dis) {
                    pos.x = move_pos.x + dis;
                    move_pos.x = pos.x;
                }
                BifurcationChecker();
                return pos;
            }

        }
        else if(!vertical && !only_horizental){
            tmp.x = move_pos.x - dis; tmp.y = move_pos.y;
            hit = Physics2D.Raycast(tmp, Vector2.zero, 0f);
            tile = map.GetTile(map.WorldToCell(hit.point));
            //Debug.Log(tile.name);
            if (tile.name.Contains("gray")) {
                pos.x -= speed * speed_rate;
                if (pos.x <= move_pos.x - dis) {
                    pos.x = move_pos.x - dis;
                    move_pos.x = pos.x;
                }
                BifurcationChecker();
                return pos;
            }

        }

        // ���� �̵�
        if (horizental && !only_vertical) {
            tmp.x = move_pos.x; tmp.y = move_pos.y + dis;
            hit = Physics2D.Raycast(tmp, Vector2.zero, 0f);
            tile = map.GetTile(map.WorldToCell(hit.point));
            //string name = tile.name;
            //Debug.Log("hit : " + hit.point + "top : " + name);
            if (tile.name.Contains("gray")) {
                pos.y += speed * speed_rate;
                if (pos.y >= move_pos.y + dis) {
                    pos.y = move_pos.y + dis;
                    move_pos.y = pos.y;
                }
                BifurcationChecker();
                return pos;
            }

        }
        else if(!horizental && !only_vertical){
            tmp.x = move_pos.x; tmp.y = move_pos.y - dis;
            hit = Physics2D.Raycast(tmp, Vector2.zero, 0f);
            tile = map.GetTile(map.WorldToCell(hit.point));
            //string name = tile.name;
            if (tile.name.Contains("gray")) {
                pos.y -= speed * speed_rate;
                if (pos.y <= move_pos.y - dis) {
                    pos.y = move_pos.y - dis;
                    move_pos.y = pos.y;
                }
                BifurcationChecker();
                return pos;
            }
        }
        //Debug.Log("lost pos");
        // �ƹ� ���⵵ ã�����ߴٸ� �Ͻ�����
        return pos;
    }

}
