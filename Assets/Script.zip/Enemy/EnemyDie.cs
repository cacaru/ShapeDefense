using System.Collections;
using UnityEngine;
using static ShapeDefenseSpace.GameData;

public class EnemyDie : MonoBehaviour
{
    [SerializeField] private GameObject DieEffect;

    private Color alpha_0 = new(0, 0, 0, 0);

    private DieEffectPool die_effect_pool;
    private EnemyPool enemy_pool;

    public void SetPool(DieEffectPool die_effect_pool, EnemyPool enemy_pool) {
        this.die_effect_pool = die_effect_pool;
        this.enemy_pool = enemy_pool;
    }

    public void Die() {
        gameObject.tag = "Dead";
        // ���ʿ��� ������Ʈ cancle
        GetComponent<EnemyMove>().speed = 0;
        transform.Find("Canvas").gameObject.SetActive(false);

        //���� ����Ʈ ����
        transform.Find("Poison").gameObject.SetActive(false);
        transform.Find("Blust").gameObject.SetActive(false);

        // ����Ʈ �ѱ�
        var effect = die_effect_pool.GetEffect(gameObject.transform.position);
        
        // Enemy Sprite alpha�� 0���� ����
        gameObject.GetComponent<SpriteRenderer>().color = alpha_0;

        StartCoroutine(DestroyObject(effect));
    }

    
    IEnumerator DestroyObject(GameObject effect) {
        yield return wfs_1_5;
        // ����Ʈ ����
        effect.tag = "Wait";
        die_effect_pool.BackEffect(effect);
        //Destroy(gameObject);

        // enemy ����
        enemy_pool.BackEnemy(gameObject);
    }
    
}
