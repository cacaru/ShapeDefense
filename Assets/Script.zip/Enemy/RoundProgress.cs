using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using ShapeDefenseSpace;

using static ShapeDefenseSpace.GameData;
using static ShapeDefenseSpace.PublicData;

public class RoundProgress : MonoBehaviour
{
    [SerializeField] private TMP_Text round;

    [SerializeField] private GameObject GameEnd;
    [SerializeField] private GameObject SuccessPanel;
    [SerializeField] private GameObject RewardContent;
    [SerializeField] private GameObject SkipBtn;
    [SerializeField] private TMP_Text RoundTimer;

    // skip 
    private TMP_Text min;
    private TMP_Text max;

    // ������ �������� ����
    private int watch_end_boss;
    private bool watcher = true;
    private readonly string final_round = "������";

    private Coroutine checker;
    private IEnumerator timer;
    private int left_time = 0;
    //private readonly float Sec = 0.016f;

    void Start()
    {
        SkipBtn.SetActive(false);
        Time.timeScale = 1;

        timer = Timer();

        //skip
        min = SkipBtn.transform.Find("Min").gameObject.GetComponent<TMP_Text>();
        max = SkipBtn.transform.Find("Max").gameObject.GetComponent<TMP_Text>();

        StartCoroutine(First());
    }

    IEnumerator First() {

        watch_end_boss = datahub.EndRound - 1;
        // 10���� �غ� ���� �� ��ƾ ����
        yield return wfs_3;

        //Debug.Log("���� ����");
        checker = StartCoroutine(Checker());
        SkipBtn.SetActive(true);
        // Ÿ�̸� ǥ��
        StartCoroutine(timer);
    }

    IEnumerator Checker() {
        while (true) {
            if (!datahub.Pause && left_time == 0) {
                left_time = 60;
                //Debug.Log(datahub.RoundNumber + " > start");
                RoundTimer.text = left_time.ToString();
                //Debug.Log("New round start");
                // �� ���� �ؽ�Ʈ ����
                datahub.RoundNumber++;
                round.text = datahub.RoundNumber.ToString();

                // ��ŵ ���� ����
                min.text = ((int)(datahub.RoundNumber * 1 * 0.6)).ToString();
                max.text = (240 + (int)(datahub.RoundNumber * 3 * 0.6)).ToString();

                // ���� ���忡 ���� �ߴ��� Ȯ��
                int going = UtilityHub.EndRoundChecker(datahub.RoundNumber);
                if (going == 2) { break; }
                else if (going == 0) {
                    round.text = final_round;
                }
                if (datahub.RoundNumber >= watch_end_boss && watcher) {
                    watcher = false;
                    StartCoroutine(EndRoundWathcer());
                }
                // 90�� ���� �� ���� ����
                gameObject.GetComponent<EnemySpawner>().NextSpawn();
                //round.text = (int.Parse(round.text) + 1).ToString();
            }
            yield return wfs_1;
        }
        RoundEnd();
    }

    IEnumerator EndRoundWathcer() {
        while (true) {
            var enemies = GameObject.FindGameObjectsWithTag("Enemy");
            // �ƹ��� �� ������ �������� �ʴٸ� ���� ����
            if ((enemies == null || enemies.Length <= 0) && datahub.KillLastBoss) {
                watcher = true;
                StopAllCoroutines();
                RoundEnd();
                watch_end_boss = 9999;
                break;
            }
            yield return wfs_1;
        }
    }

    IEnumerator Timer() {

        while (true){
            yield return wfs_1;
            if (!datahub.Pause) {
                left_time--;
                RoundTimer.text = left_time.ToString();
            }
        }
        
    }

    public void RoundEnd() {
        // ���� ���ᰡ �Ǿ��� �� ������ ��µ� �����ߴٸ� == enemy_boss�� �������� ������ ���� ���� �߰� 
        // Enemy boss�� Ȯ��
        int ending = 0;
        var enemies = GameObject.FindGameObjectsWithTag("Enemy");
        int left_unit_count = enemies.Length;
        foreach (var enemy in enemies) {
            // ���� �ִ� ���� ����
            if (enemy.name.Equals("enemy_boss")) {
                ending = 1;
                break;
            }
        }
        if(left_unit_count >= datahub.MaxEnemyCounter) {
            ending = 1;
        }

        string text;
        bool success = false;
        // �����ߴٸ� ���� ���� ȭ�鿡�� ���� announce 
        if (ending == 1) {
            text = "���� ����";
        }
        // ����
        else {
            success = true;
            text = "���� �Ϸ�";
        }
        // ���� ����
        // ���������� ���� �� ���� + 1
        // ������ ���� ���ּ� �� �ݺ���Ͽ� ����
        // 1ȸ ���� Ȯ�� �Ϲ� 40% ���� 40% ��ǰ 15% ����ǰ 4% �������� 1%

        // [0] == unit_id_selecter 
        // [1] == piece_counter
        int[] random_select_result;
        string query;
        // success = 3 / fail = 2
        random_select_result = GenerateRandomReward(success);
        var unit = datahub.Unit_dic[random_select_result[0]] as Unit;
        unit.Piece += random_select_result[1] + (datahub.Difficulty - 1);
        // modify db
        query = UtilityHub.query_builder.Append("UPDATE unit SET piece=")
                                        .Append(unit.Piece)
                                        .Append(" WHERE id=")
                                        .Append(unit.Id)
                                        .ToString();
        UtilityHub.query_builder.Clear();
        modifyDB.ControllDB(query, "unit");
        // reward prefab ����
        GameObject pref = Instantiate(_game_clear_reward_obj, RewardContent.transform.position, RewardContent.transform.rotation);
        pref.transform.SetParent(RewardContent.transform, false);
        pref.transform.Find("Grade").GetComponent<Image>().color = unit.Grade switch {
            "E" => color_e,
            "D" => color_d,
            "C" => color_c,
            "B" => color_b,
            "A" => color_a,
            "S" => color_s,
            _ => core_color,
        };
        pref.transform.Find("Image").GetComponent<Image>().sprite = UtilityHub.GetSprite(unit.Id); // Resources.Load<Sprite>(UtilityHub.GetPath(unit.Id));
        pref.transform.Find("Piece").GetComponent<TMP_Text>().text = random_select_result[1].ToString();


        random_select_result = GenerateRandomReward(success);
        unit = datahub.Unit_dic[random_select_result[0]] as Unit;
        unit.Piece += random_select_result[1] + (datahub.Difficulty - 1);
        // modify db
        query = UtilityHub.query_builder.Append("UPDATE unit SET piece=")
                                        .Append(unit.Piece)
                                        .Append(" WHERE id=")
                                        .Append(unit.Id)
                                        .ToString();
        UtilityHub.query_builder.Clear();
        modifyDB.ControllDB(query, "unit");
        // reward prefab ����
        GameObject pref_2 = Instantiate(_game_clear_reward_obj, RewardContent.transform.position, RewardContent.transform.rotation);
        pref_2.transform.SetParent(RewardContent.transform, false);
        pref_2.transform.Find("Grade").GetComponent<Image>().color = unit.Grade switch {
            "E" => color_e,
            "D" => color_d,
            "C" => color_c,
            "B" => color_b,
            "A" => color_a,
            "S" => color_s,
            _ => core_color,
        };
        pref_2.transform.Find("Image").GetComponent<Image>().sprite = UtilityHub.GetSprite(unit.Id); // Resources.Load<Sprite>(UtilityHub.GetPath(unit.Id));
        pref_2.transform.Find("Piece").GetComponent<TMP_Text>().text = random_select_result[1].ToString();

        if (success) {
            random_select_result = GenerateRandomReward(success);
            unit = datahub.Unit_dic[random_select_result[0]] as Unit;
            unit.Piece += random_select_result[1] + (datahub.Difficulty - 1);
            // modify db
            query = UtilityHub.query_builder.Append("UPDATE unit SET piece=")
                                            .Append(unit.Piece)
                                            .Append(" WHERE id=")
                                            .Append(unit.Id)
                                            .ToString();
            UtilityHub.query_builder.Clear();
            modifyDB.ControllDB(query, "unit");
            // reward prefab ����
            GameObject pref_3 = Instantiate(_game_clear_reward_obj, RewardContent.transform.position, RewardContent.transform.rotation);
            pref_3.transform.SetParent(RewardContent.transform, false);
            pref_3.transform.Find("Grade").GetComponent<Image>().color = unit.Grade switch {
                "E" => color_e,
                "D" => color_d,
                "C" => color_c,
                "B" => color_b,
                "A" => color_a,
                "S" => color_s,
                _ => core_color,
            };
            pref_3.transform.Find("Image").GetComponent<Image>().sprite = UtilityHub.GetSprite(unit.Id); // Resources.Load<Sprite>(UtilityHub.GetPath(unit.Id));
            pref_3.transform.Find("Piece").GetComponent<TMP_Text>().text = random_select_result[1].ToString();
        }

        // ����ġ ȹ��
        // �⺻ ����ġ -- 5~10
        // �������� �߰� ����ġ ( �������� ��ȣ * 2 )
        // ���̵� �߰� ����ġ ( ���̵� * 3 )
        int exp = success ? Random.Range(5, 11) + datahub.Difficulty * 5 : Random.Range(5, 11);
        datahub.User.Experience += exp;

        // ���̵��� ���� ��� ����
        float gold = success ? Random.Range(100, 501) + datahub.Difficulty * Random.Range(4, 7) : (datahub.RoundNumber * 1.2f * 3);
        // ��� ��� ȹ�� ������ ����� ��
        if(datahub.User.StatusClearDotLevel > 0) {
            gold += gold * datahub.User.StatusClearDotLevel * 0.05f;
        }
        datahub.User.Dot += (int)gold;
        query = UtilityHub.query_builder.Append("UPDATE user SET dot=")
                                        .Append(datahub.User.Dot)
                                        .Append(", experience=")
                                        .Append(datahub.User.Experience)
                                        .ToString();
        modifyDB.ControllDB(query, "user");
        UtilityHub.query_builder.Clear();

        // ���� ����
        // (10���� Ŭ����) ������ ������ Ŭ�����ϴ� ������ ������
        //achieve_observer.KillBoss(datahub.RoundNumber);
        achieve_observer.RoundClearQuestCheck(datahub.RoundNumber);
        if (success) {
            achieve_observer.FirstDifficultyClearCheck();
        }
        
        // ��� ���� �г� ����
        SuccessPanel.transform.Find("Gold").gameObject.GetComponent<TMP_Text>().text =
            UtilityHub.query_builder.Append(((int)gold).ToString()).ToString();
        UtilityHub.query_builder.Clear();

        SuccessPanel.transform.Find("Exp").gameObject.GetComponent<TMP_Text>().text =
            UtilityHub.query_builder.Append(exp.ToString()).ToString();
        UtilityHub.query_builder.Clear();

        SuccessPanel.SetActive(true);
        
        GameEnd.transform.Find("background").Find("SettingText").GetComponent<TMP_Text>().text = text;
        GameEnd.SetActive(true);
    }

    private int[] GenerateRandomReward(bool success) {
        int random_number;
        int unit_id_selecter;
        int piece_counter;

        random_number = Random.Range(1, 101);
        // 36 28 20 10 5 1
        // E
        if (random_number >= 65) {
            // E 3���� �ϳ� �ٽ� ������
            unit_id_selecter = Random.Range(1001, 1004);
        }
        // D
        else if (random_number < 65 && random_number >= 37) {
            // D �� �ϳ�
            unit_id_selecter = Random.Range(2001, 2004);
        }
        // C
        else if (random_number < 37 && random_number >= 17) {
            unit_id_selecter = Random.Range(3001, 3015);
        }
        // B
        else if (random_number < 17 && random_number >= 7) {
            unit_id_selecter = Random.Range(4001, 4012);
        }
        // A
        else if (random_number < 7 && random_number >= 2) {
            unit_id_selecter = Random.Range(5001, 5006);
        }
        // S
        else {
            unit_id_selecter = Random.Range(6001, 6006);
        }
        piece_counter = success ? Random.Range(1, 17) : Random.Range(1, 9);

        return new int[2] { unit_id_selecter, piece_counter };
    }

    public void Pause() {
        //StopCoroutine(checker);
        //Time.timeScale = 0;
        // enemy ���߱�
        StopCoroutine(timer);
        pause.EnemyPauseSetting(false);
    }

    public void ReStart() {
        //StartCoroutine(checker);
        //Time.timeScale = 1;
        StartCoroutine(timer);
        pause.EnemyPauseSetting(true);
    }

    // �ǳʶٱ� (��ŵ�ϱ�)
    public void SkipWaitTime() {
        // �������¸� ������ �ƹ� �ൿ���� ����
        if (datahub.Pause) {
            return;
        }
        // boss�� ������ ����Ÿ�̸ӵ� ��ŵ�ؾ���
        // ���� �ð���ŭ ��ŵ
        gameObject.GetComponent<EnemySpawner>().SkipBossTimer(left_time);

        // ���� �ڷ�ƾ�� ������Ű��
        left_time = 0;
        RoundTimer.text = left_time.ToString();
        StopCoroutine(checker);
        //Debug.Log("Skip):");

        // �ٽ� �����Ŵ
        checker = StartCoroutine(Checker());

        // ��ŵ ��ư�� 5�ʰ� ���
        SkipBtn.SetActive(false);
        StartCoroutine(nameof(SkipBtnStoper));

        // ��ȯ�� ���� ���� �� ��ŭ�� dot�� �߰� ������ (��ŵ �޸�Ʈ)
        datahub.Dot += (datahub.EnemyCounter - datahub.NowEnemyCounter) * Random.Range(3, 6) + (int)(datahub.RoundNumber * Random.Range(1, 4) * 0.6);
    }

    IEnumerator SkipBtnStoper() {
        while (true) {
            yield return wfs_5;
            if (!datahub.Pause) {
                // skipobtn �����
                SkipBtn.SetActive(true);
                break;
            }
        }
        
    }
}
