using System.Collections;
using TMPro;
using UnityEngine;

using static ShapeDefenseSpace.GameData;

public class EnemyCounter : MonoBehaviour
{
    [SerializeField] private TMP_Text CounterText;
    [SerializeField] private TMP_Text MaxText;
    [SerializeField] private GameObject GameOver;
    private int counter = 0;

    //private Color FAIL_COLOR = new(1f, 110 / 255f, 110 / 255f, 1f);

    private int max_enemy_count;
    private void Start() {

        // max enemy text setting
        max_enemy_count = datahub.MaxEnemyCounter;
        MaxText.text = max_enemy_count.ToString();

        StartCoroutine(Counting());
    }

    IEnumerator Counting() {
        while (true) {
            if (!datahub.Pause) {
                counter = GameObject.FindGameObjectsWithTag("Enemy").Length;
                CounterText.text = counter.ToString();
                // counter�� ������ datahub�� �����ؼ� ����
                if (counter >= max_enemy_count) {

                    // ���� ���� ȭ�� ����
                    gameObject.GetComponent<RoundProgress>().RoundEnd();

                    // ���� ����
                    gameObject.GetComponent<EnemySpawner>().StopSpawn();
                    gameObject.GetComponent<EnemySpawner>().enabled = false;

                    // ���ּ� ī��Ʈ ����
                    gameObject.GetComponent<EnemyCounter>().enabled = false;
                    // ���� ���� ����
                    gameObject.GetComponent<RoundProgress>().Pause();
                    gameObject.GetComponent<RoundProgress>().enabled = false;

                    // speed ������� ����
                    datahub.SpeedRate = 1;

                    //��� enemy ����
                    var enemies = gameObject.GetComponentInChildren<Transform>();
                    foreach (Transform t in enemies) {
                        if (t != transform) {
                            Destroy(t.gameObject);
                        }
                    }
                    break;
                }
                
            }
            yield return wfs_1;
        }
        
    }

}
