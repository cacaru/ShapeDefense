using System.Collections.Generic;
using UnityEngine;

public class BulletPool : MonoBehaviour
{
    [SerializeField] private GameObject BulletPrefabs;
    [SerializeField] private int counter;

    [SerializeField] private DieEffectPool dieeffectpool;

    private readonly Queue<GameObject> bulletqueue = new();

    void OnEnable() {
        Initialize(100);
    }

    private GameObject CreateBullet() {
        var bullet = Instantiate(BulletPrefabs, transform);
        // �θ� ������ bullet�� ���� �� ����
        bullet.SetActive(false);
        counter++;
        return bullet;
    }

    private void Initialize(int count) {
        for (int i = 0; i < count; i++) {
            bulletqueue.Enqueue(CreateBullet());
        }
    }

    /// <summary>
    /// �ܺο��� pool�� ����ִ� ������Ʈ�� ����
    /// </summary>
    /// <returns>bullet ������Ʈ</returns>
    public GameObject GetObject(GameObject parent_field, GameObject target, Damage damage) {
        GameObject bullet;
        if (bulletqueue.Count > 0) {
            bullet = bulletqueue.Dequeue();   
        }
        else {
            bullet = CreateBullet();
        }

        bullet.transform.SetParent(parent_field.transform, false);
        bullet.GetComponent<BulletMove>().SetPos(parent_field.transform.position);
        bullet.GetComponent<BulletMove>().damage = damage;
        bullet.GetComponent<BulletMove>().SetPool(this, dieeffectpool);
        bullet.SetActive(true);
        bullet.GetComponent<BulletMove>().Target = target;
        return bullet;
    }

    /// <summary>
    /// ��� �Ϸ�� ������Ʈ ��ȯ
    /// </summary>
    /// <param name="bullet"></param>
    public void BackObject(GameObject bullet) {
        bullet.transform.SetParent(gameObject.transform, false);
        bullet.GetComponent<BulletMove>().InitMove();
        bullet.SetActive(false);
        bulletqueue.Enqueue(bullet);

        // bulletqueue�� ����� 512�� �Ѿ�� ����
        if(bulletqueue.Count >= 512) {
            Resizing();
        }
    }

    /// <summary>
    /// ź���� ���� �缳��
    /// </summary>
    public void Resizing() {
        bulletqueue.Clear();
        Initialize(100);
    }
}
