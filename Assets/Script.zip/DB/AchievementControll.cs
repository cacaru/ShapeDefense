using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using ShapeDefenseSpace;

using static ShapeDefenseSpace.GameData;
using static ShapeDefenseSpace.PublicData;
using System.Text;

/// <summary>
/// ������ �����ϴ� �Լ�
/// </summary>
/// 
public class AchievementControll : QuestController
{
    [SerializeField] private GameObject A_Content;
    [SerializeField] private GameObject A_AllReciveBtn;

    private readonly StringBuilder builder = new();

    // ���� ������ �����ص� ����

    private readonly int announce_size = datahub.UnitCounter.Count;
    private int reward_gold_summary = 0;

    void Start()
    {
        Content = A_Content;
        AllReciveBtn = A_AllReciveBtn;

        Show();
    }

    public override void Show() {
        PageReset();
        // ���ŵ� ������ �������� ���� ��� ����
        // list�� ������
        ArrayList ori_list = datahub.Achievement;
        int size = ori_list.Count;

        for (int i = 1; i < size; i++) {
            Achievement achieve = ori_list[i] as Achievement;
            // checker�� 1�̰� repeat�� false�� �͵� ��Ƶα� == �Ϸ�Ȱ�
            if (achieve.Checker == 1 && achieve.Repeat == false) {
                already_do.Add(achieve);
            }
            // �ޱⰡ ������ ���� ��Ƶα�
            else if (achieve.CanRecive) {
                can_recive.Add(achieve);
            }
            // �� �� ������ �̿��� ������ �����ϱ�
            else {
                normal.Add(achieve);
            }
        }

        /*
         * ������ �����׸�
         * Background - Color
         * Name - name(text)
         * Slider - value ����
         * Counter - text
         * Recive Color Controll
         * -> �ֻ����� BtnStateControl����
         *  -> SlideChecker �� value ����
         *  -> Counter�� �� �ۼ�
         */
        // �ޱⰡ���� �������� ���
        size = can_recive.Count;
        // �ޱ� �����ϸ� ��� �ޱ� ��ư�� ���
        if (size > 0) {
            //AllReciveBtn.SetActive(true);
            AllReciveBtn.GetComponent<Image>().color = BTN_ACTIVATE_STATE;
            AllReciveBtn.transform.Find("Text").gameObject.GetComponent<TMP_Text>().color = ACTIVE_TEXT;
            AllReciveBtn.GetComponent<Button>().interactable = true;
        }
        else {
            //AllReciveBtn.SetActive(false);
            AllReciveBtn.GetComponent<Image>().color = BTN_DISABLE_STATE;
            AllReciveBtn.transform.Find("Text").gameObject.GetComponent<TMP_Text>().color = DISABLE_TEXT;
            AllReciveBtn.GetComponent<Button>().interactable = false;
        }

        for (int i = 0; i < size; i++) {
            Achievement now = can_recive[i] as Achievement;
            GameObject prefab = Instantiate(_quest_obj, Content.transform.position, Content.transform.rotation);
            // value ����
            prefab.transform.SetParent(Content.transform, false);
            prefab.transform.Find("BackGround").gameObject.GetComponent<Image>().color = DEFAULT_BACKGROUND;
            prefab.transform.Find("Name").gameObject.GetComponent<TMP_Text>().text = now.Name;

            if (now.Repeat) {
                // ���ѷ��� ������ repeatreward�� ����
                int tmp_val = now.EndlessValue * (now.Checker + 1);
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = tmp_val;

                prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().text = builder.Append(now.Counter.ToString())
                                                                                                    .Append(" / ")
                                                                                                    .Append(tmp_val)
                                                                                                    .ToString();
                builder.Clear();
            }
            else {
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = 1;
                prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().text = builder.Append(now.Counter.ToString())
                                                                                                                    .Append(" / 1")
                                                                                                                    .ToString();
                builder.Clear();
            }
            prefab.GetComponent<AchievementSliderChecker>().NowVal = now.Counter;
            prefab.GetComponent<AchievementReciveBtnState>().ColorSetting(true);
            //prefab.AddComponent<AchievementRecive>();
            prefab.transform.Find("Recive").gameObject
                            .GetComponent<Button>().onClick
                            .AddListener(() => Recive(now.Id));
            //prefab.GetComponent<AchievementRecive>().Id = now.Id;

            // untouchable
            prefab.transform.GetChild(2).gameObject.GetComponent<Slider>().interactable = false;

        }

        // ������ ���
        size = normal.Count;
        for (int i = 0; i < size; i++) {
            Achievement now = normal[i] as Achievement;
            GameObject prefab = Instantiate(_quest_obj, Content.transform.position, Content.transform.rotation);
            // value ����
            prefab.transform.SetParent(Content.transform, false);
            prefab.transform.Find("BackGround").gameObject.GetComponent<Image>().color = DEFAULT_BACKGROUND;
            prefab.transform.Find("Name").gameObject.GetComponent<TMP_Text>().text = now.Name;
            if (now.Repeat) {
                // �ݺ� ������ repeatreward�� ����
                int tmp_val = now.EndlessValue * (now.Checker + 1);
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = tmp_val;

                prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().text = builder.Append(now.Counter.ToString())
                                                                                                    .Append(" / ")
                                                                                                    .Append(tmp_val)
                                                                                                    .ToString();
                builder.Clear();
            }
            else {
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = 1;
                prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().text = builder.Append(now.Counter.ToString())
                                                                                                    .Append(" / 1")
                                                                                                    .ToString();
                builder.Clear();
            }
            prefab.GetComponent<AchievementSliderChecker>().NowVal = now.Counter;
            
            prefab.GetComponent<AchievementReciveBtnState>().ColorSetting(false);
            //prefab.AddComponent<AchievementRecive>();
            prefab.transform.Find("Recive").gameObject
                            .GetComponent<Button>().onClick
                            .AddListener(() => Recive(now.Id));
            //prefab.GetComponent<AchievementRecive>().Id = now.Id;

            // untouchable
            prefab.transform.GetChild(2).gameObject.GetComponent<Slider>().interactable = false;
        }

        // �Ϸ�� �� ���
        size = already_do.Count;
        for (int i = 0; i < size; i++) {
            Achievement now = already_do[i] as Achievement;
            GameObject prefab = Instantiate(_quest_obj, Content.transform.position, Content.transform.rotation);
            // value ����
            prefab.transform.SetParent(Content.transform, false);
            prefab.transform.Find("BackGround").gameObject.GetComponent<Image>().color = DEACTIVATE_BACKGROUND;
            prefab.transform.Find("Name").gameObject.GetComponent<TMP_Text>().text = now.Name;
            if (now.Repeat) {

                int tmp_val = now.EndlessValue * (now.Checker + 1);
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = tmp_val;

            }
            else {
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = 1;
            }
            prefab.GetComponent<AchievementSliderChecker>().NowVal = now.Counter;
            prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().text = Complete_Text;
            prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().color = DISABLE_TEXT;
            prefab.transform.Find("Recive").Find("Text").gameObject.GetComponent<TMP_Text>().text = Complete_Text;
            prefab.transform.Find("Slider").Find("fill_area").Find("Fill").gameObject.GetComponent<Image>().color = BTN_DISABLE_STATE;
            prefab.GetComponent<AchievementReciveBtnState>().ColorSetting(false);
            //prefab.AddComponent<AchievementRecive>();
            prefab.transform.Find("Recive").gameObject
                            .GetComponent<Button>().onClick
                            .AddListener(() => Recive(now.Id));
            //prefab.GetComponent<AchievementRecive>().Id = now.Id;

            // untouchable
            prefab.transform.GetChild(2).gameObject.GetComponent<Slider>().interactable = false;
        }

        // ��� ��������� �ʱ�ȭ
        InitArrayList();
    }

    public override void AllRecive() {
        // ���ŵ� ������ �������� ���� ��� ����
        // list�� ������
        
        int size = datahub.Achievement.Count;

        // �ޱ� ������ ������ Ȯ���ؼ� ������ Ƚ���� ���� �ޱ�
        for (int i = 0; i < size; i++) {
            Achievement achieve = datahub.Achievement[i] as Achievement;
            string query;

            // �ޱⰡ ������ ���� �ޱ�
            if (achieve.CanRecive) {

                GetReward(achieve);

                achieve.CanRecive = false;

                // �ٽ� ������ �ִ� ȯ������ ��˻�
                if (achieve.Repeat) {

                    // �ݺ� �����̸� ���� ������ �����ߴ��� Ȯ���ؼ� ���� ������� ��� Ÿ�Ա�
                    bool repeat_checker = true;
                    //Debug.Log(achieve.Checker + " // " + achieve.RepeatRewardRequest.Count + " // " + achieve.RepeatRewardRequest[0]);

                    // ���� �ݺ���
                    while (repeat_checker) {
                        int requare = (achieve.Checker+1) * achieve.EndlessValue;
                        if (achieve.Counter >= requare) {
                            GetReward(achieve);
                            achieve.Checker++;
                        }
                        else {
                            repeat_checker = false;
                        }
                    }

                }
                else {
                    achieve.Checker++;
                }

                // ������ checker�� ������Ʈ
                query = builder.Append("UPDATE achievement SET checker=")
                                                       .Append(achieve.Checker)
                                                       .Append(" WHERE id=")
                                                       .Append(achieve.Id)
                                                       .ToString();
                modifyDB.ControllDB(query, "achieve");
                builder.Clear();
            }
        }

        // piece �ϳ��� ������ type 2
        // ������ ����ȭ�ϰ� type1
        bool checker = false;
        for(int i = 0; i < announce_size; i++) {
            if (datahub.UnitCounter[datahub.Unit_Ids[i]] > 0) {
                checker = true;
                break;
            }
        }

        string announce_text = "";
        int type = 2;
        if (!checker) {
            type = 1;
            announce_text = ReciveAnnounce();
        }
        
        // ������ ���ȯ
        Achieve_Connector.Connect();
        
        // Ȯ�� â ����
        ReciveConfirm.Instance.OpenConfirmWindow(announce_text, reward_gold_summary, type);
    }

    public override void Recive(int id) {

        //GameObject.Find("Canvas").transform.Find("Announce").Find("Panel").Find("Image").Find("Test").gameObject.GetComponent<TMP_Text>().text = "in recive";
        //Debug.Log("in Recive");
        // ȹ�� �������� Ȯ��
        Achievement achieve = datahub.Achievement[id] as Achievement;
        
        if (achieve.CanRecive) {
            string announce_text = "";

            GetReward(achieve);

            achieve.CanRecive = false;
            // checker�� �߰��ϰ�
            achieve.Checker++;
            // DB�� modify�ϰ� -> checker�� ������Ʈ ���ָ� ��
            string query = builder.Append("UPDATE achievement SET checker=")
                                            .Append(achieve.Checker)
                                            .Append(" WHERE id=")
                                            .Append(achieve.Id)
                                            .ToString();
            modifyDB.ControllDB(query, "achieve");
            builder.Clear();


            // piece �ϳ��� ������ type 2
            // ������ ����ȭ�ϰ� type1
            bool checker = false;
            for (int i = 0; i < announce_size; i++) {
                if (datahub.UnitCounter[datahub.Unit_Ids[i]] > 0) {
                    checker = true;
                    break;
                }
            }

            int type = 2;
            if (!checker) {
                type = 1;
                announce_text = ReciveAnnounce();
            }

            // ������ ���ȯ
            Achieve_Connector.Connect();

            // Ȯ�� â ����
            ReciveConfirm.Instance.OpenConfirmWindow(announce_text, reward_gold_summary, type);
        }
    }

    /// <summary>
    /// ���� ���� �ޱ� �Լ�
    /// </summary>
    /// <param name="achieve">���� ������ �����ϴ� ���� Ŭ����</param>
    private void GetReward(Achievement achieve) {
        
        // �����带 ����
        bool piece_check = false;
        int recive_size = achieve.RewardList.Count;
        int counter;
        string query;

        for (int i = 0; i < recive_size; i++) {
            // ���� ��� Ȯ��
            switch (achieve.RewardList[i] as string) {
                case "gold":
                    int reward_gold = (int)achieve.RewardVal[i];
                    datahub.User.Dot += reward_gold;
                    query = UtilityHub.query_builder.Append("UPDATE user SET dot=")
                                                    .Append(datahub.User.Dot)
                                                    .ToString();
                    UtilityHub.query_builder.Clear();
                    modifyDB.ControllDB(query, "user");

                    // ���� ���� ���
                    reward_gold_summary += reward_gold;
                    break;
                // e
                case "e":
                    piece_check = true;
                    counter = (int)achieve.RewardVal[i];
                    UtilityHub.SelectRecivePiece( 1, counter);
                    
                    break;
                // d
                case "d":
                    piece_check = true;
                    counter = (int)achieve.RewardVal[i];
                    UtilityHub.SelectRecivePiece(2, counter);

                    break;
                // c
                case "c":
                    piece_check = true;
                    counter = (int)achieve.RewardVal[i];
                    UtilityHub.SelectRecivePiece(3, counter);

                    break;
                // b
                case "b":
                    counter = (int)achieve.RewardVal[i];
                    UtilityHub.SelectRecivePiece(4, counter);
                        
                    break;
                // a
                case "a":
                    piece_check = true;
                    counter = (int)achieve.RewardVal[i];
                    UtilityHub.SelectRecivePiece(5, counter);
                    
                    break;

                //s
                case "s":
                    piece_check = true;
                    counter = (int)achieve.RewardVal[i];
                    UtilityHub.SelectRecivePiece(6, counter);

                    break;
            }

            // ���� ���� Ȯ��
            if (piece_check) {
                for (int k = 0; k < announce_size; k++) {
                    if (datahub.UnitCounter[datahub.Unit_Ids[k]] > 0) {
                        var unit = datahub.Unit_dic[datahub.Unit_Ids[k]] as Unit;
                        unit.Piece += datahub.UnitCounter[datahub.Unit_Ids[k]];
                        query = builder.Append("UPDATE unit SET piece=")
                                       .Append(unit.Piece)
                                       .Append(" WHERE id=")
                                       .Append(unit.Id)
                                       .ToString();
                        builder.Clear();
                        modifyDB.ControllDB(query, "unit");

                        // unit upgrade check
                        UIUnitPageSetting.Instance.CheckUnitLevel();
                    }
                }
            }
        }
    }

    private string ReciveAnnounce() {
        string announce_text = "";
        //total gold�� ������ 
        if (reward_gold_summary > 0) {
            announce_text += builder.Append("��� + ")
                                    .Append(reward_gold_summary)
                                    .Append('\n')
                                    .ToString();
            builder.Clear();
        }
        reward_gold_summary = 0;
        //datahub.InitCounter();

        return announce_text;
    }
}
