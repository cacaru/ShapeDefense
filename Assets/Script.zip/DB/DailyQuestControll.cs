using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using ShapeDefenseSpace;
using static ShapeDefenseSpace.PublicData;
using static ShapeDefenseSpace.GameData;
using System.Text;

/// <summary>
/// ��������Ʈ ���� �Լ�
/// </summary>
/// 
public class DailyQuestControll : QuestController
{
    [SerializeField] private GameObject D_Content;
    [SerializeField] private GameObject D_AllReciveBtn;

    private readonly StringBuilder builder = new();

    void Start()
    {
        Content = D_Content;
        AllReciveBtn = D_AllReciveBtn;

        Show();
    }

    public override void Show() {
        PageReset();
        // ���ŵ� ������ �������� ���� ��� ����
        // list�� ������
        ArrayList ori_list = datahub.DailyQuest;
        int size = ori_list.Count;

        for (int i = 1; i < size; i++) {
            DailyQuest achieve = ori_list[i] as DailyQuest;            
            // �Ϸ�Ȱ� ��Ƶα� == checker == 1
            if (achieve.Checker == 1 ) {
                already_do.Add(achieve);
            }
            // �ޱⰡ ������ ���� ��Ƶα�
            else if (achieve.CanRecive) {
                can_recive.Add(achieve);
            }
            // �� �� ������ �̿��� ������ �����ϱ�
            else {
                normal.Add(achieve);
            }
        }

        /*
         * ������ �����׸�
         * Background - Color
         * Name - name(text)
         * Slider - value ����
         * Counter - text
         * Recive Color Controll
         * -> �ֻ����� BtnStateControl����
         *  -> SlideChecker �� value ����
         *  -> Counter�� �� �ۼ�
         */
        // �ޱⰡ���� �������� ���
        size = can_recive.Count;
        // �ޱ� �����ϸ� ��� �ޱ� ��ư�� ���
        if(size > 0) {
            //AllReciveBtn.SetActive(true);
            AllReciveBtn.GetComponent<Image>().color = BTN_ACTIVATE_STATE;
            AllReciveBtn.transform.Find("Text").gameObject.GetComponent<TMP_Text>().color = ACTIVE_TEXT;
            AllReciveBtn.GetComponent<Button>().interactable = true;
        }
        else {
            //AllReciveBtn.SetActive(false);
            AllReciveBtn.GetComponent<Image>().color = BTN_DISABLE_STATE;
            AllReciveBtn.transform.Find("Text").gameObject.GetComponent<TMP_Text>().color = DISABLE_TEXT;
            AllReciveBtn.GetComponent<Button>().interactable = false;
        }

        for (int i = 0; i < size; i++) {
            DailyQuest now = can_recive[i] as DailyQuest;
            GameObject prefab = Instantiate(_quest_obj, Content.transform.position, Content.transform.rotation);
            // value ����
            prefab.transform.SetParent(Content.transform, false);
            prefab.transform.Find("BackGround").gameObject.GetComponent<Image>().color = DEFAULT_BACKGROUND;
            prefab.transform.Find("Name").gameObject.GetComponent<TMP_Text>().text = now.Name;

            // �䱸ġ�� 0���� ū �� �̹Ƿ� �䱸ġ�� �߰� �ۼ��������
            if (now.RequestCounter > 0) {
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = now.RequestCounter;
                prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().text = builder.Append(now.Counter.ToString())
                                                                                                    .Append(" / ")
                                                                                                    .Append(now.RequestCounter.ToString())
                                                                                                    .ToString();
                builder.Clear();
            }
            else {
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = 1;
                prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().text = builder.Append(now.Counter.ToString())
                                                                                                    .Append(" / 1")
                                                                                                    .ToString();
                builder.Clear();

            }

            prefab.GetComponent<AchievementSliderChecker>().NowVal = now.Counter;
            prefab.GetComponent<AchievementReciveBtnState>().ColorSetting(true);
            //prefab.AddComponent<DailyQuestRecive>();
            prefab.transform.Find("Recive").gameObject
                            .GetComponent<Button>().onClick
                            .AddListener(() => Recive(now.Id));
            //prefab.GetComponent<DailyQuestRecive>().Id = now.Id;

            // untouchable
            prefab.transform.GetChild(2).gameObject.GetComponent<Slider>().interactable = false;

        }

        // ������ ���
        size = normal.Count;
        for (int i = 0; i < size; i++) {
            DailyQuest now = normal[i] as DailyQuest;
            GameObject prefab = Instantiate(_quest_obj, Content.transform.position, Content.transform.rotation);
            // value ����
            prefab.transform.SetParent(Content.transform, false);
            prefab.transform.Find("BackGround").gameObject.GetComponent<Image>().color = DEFAULT_BACKGROUND;
            prefab.transform.Find("Name").gameObject.GetComponent<TMP_Text>().text = now.Name;

            // �䱸ġ�� 0���� ū �� �̹Ƿ� �䱸ġ�� �߰� �ۼ��������
            if (now.RequestCounter > 0) {
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = now.RequestCounter;
                prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().text = builder.Append(now.Counter.ToString())
                                                                                                    .Append(" / ")
                                                                                                    .Append(now.RequestCounter.ToString())
                                                                                                    .ToString();
                builder.Clear();
            }
            else {
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = 1;
                prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().text = builder.Append(now.Counter.ToString())
                                                                                                    .Append(" / 1")
                                                                                                    .ToString();
                builder.Clear();

            }
            prefab.GetComponent<AchievementSliderChecker>().NowVal = now.Counter;
            
            prefab.GetComponent<AchievementReciveBtnState>().ColorSetting(false);
            //prefab.AddComponent<DailyQuestRecive>();
            prefab.transform.Find("Recive").gameObject
                            .GetComponent<Button>().onClick
                            .AddListener(() => Recive(now.Id));
            //prefab.GetComponent<DailyQuestRecive>().Id = now.Id;

            // untouchable
            prefab.transform.GetChild(2).gameObject.GetComponent<Slider>().interactable = false;
        }

        // �Ϸ�� �� ���
        size = already_do.Count;
        for (int i = 0; i < size; i++) {
            DailyQuest now = already_do[i] as DailyQuest;
            GameObject prefab = Instantiate(_quest_obj, Content.transform.position, Content.transform.rotation);
            // value ����
            prefab.transform.SetParent(Content.transform, false);
            prefab.transform.Find("BackGround").gameObject.GetComponent<Image>().color = DEACTIVATE_BACKGROUND;
            prefab.transform.Find("Name").gameObject.GetComponent<TMP_Text>().text = now.Name;
            // �䱸ġ�� 0���� ū �� �̹Ƿ� �䱸ġ�� �߰� �ۼ��������
            if (now.RequestCounter > 0) {
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = now.RequestCounter;
            }
            else {
                prefab.GetComponent<AchievementSliderChecker>().NeedVal = 1;

            }
            
            prefab.GetComponent<AchievementSliderChecker>().NowVal = now.Counter;
            prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().text = Complete_Text;
            prefab.transform.Find("Counter").gameObject.GetComponent<TMP_Text>().color = DISABLE_TEXT;
            prefab.transform.Find("Recive").Find("Text").gameObject.GetComponent<TMP_Text>().text = Complete_Text;
            prefab.transform.Find("Slider").Find("fill_area").Find("Fill").gameObject.GetComponent<Image>().color = BTN_DISABLE_STATE;
            prefab.GetComponent<AchievementReciveBtnState>().ColorSetting(false);
            //prefab.AddComponent<DailyQuestRecive>();
            prefab.transform.Find("Recive").gameObject
                            .GetComponent<Button>().onClick
                            .AddListener(() => Recive(now.Id));
            //prefab.GetComponent<DailyQuestRecive>().Id = now.Id;

            // untouchable
            prefab.transform.GetChild(2).gameObject.GetComponent<Slider>().interactable = false;
        }
        InitArrayList();
    }


    public override void AllRecive() {
        // ���ŵ� ������ �������� ���� ��� ����
        // list�� ������
        ArrayList ori_list = datahub.DailyQuest;
        int size = ori_list.Count;
        int total_gold = 0;
        int total_exp = 0;
        string query;

        // �ޱ� ������ ������ Ȯ���ؼ� ������ Ƚ���� ���� �ޱ�
        for (int i = 0; i < size; i++) {
            ori_list = datahub.DailyQuest;
            DailyQuest achieve = ori_list[i] as DailyQuest;
            // �ޱⰡ ������ ���� �ޱ�
            if (achieve.CanRecive) {

                // ���� ����ġ ���� ����
                int reward_gold = (int)achieve.RewardVal[0];
                int reward_exp = (int)achieve.RewardVal[1];

                total_gold += reward_gold;
                total_exp += reward_exp;

                achieve.CanRecive = false;
                achieve.Checker++;
 
                // ������ checker�� ������Ʈ
                query = builder.Append("UPDATE dailyquest SET checker=")
                                                       .Append(achieve.Checker)
                                                       .Append(" WHERE id=")
                                                       .Append(achieve.Id)
                                                       .ToString();
                modifyDB.ControllDB(query, "daily");
                builder.Clear();

                // ���� ����� update 
                //Daily_Connector.Connect();
            }

        }

        string announce_text = "";

        //total gold�� ������ 
        if (total_gold > 0) {
            announce_text += builder.Append("��� + ")
                                                 .Append(total_gold)
                                                 .Append('\n')
                                                 .ToString();
            builder.Clear();
        }

        //total exp�� ������ 
        if (total_exp > 0) {
            announce_text += builder.Append("����ġ + ")
                                                 .Append(total_exp)
                                                 .Append('\n')
                                                 .ToString();
            builder.Clear();
        }

        datahub.User.Dot += total_gold;
        datahub.User.Experience += total_exp;

        query = builder.Append("UPDATE user SET dot=")
                                        .Append(datahub.User.Dot)
                                        .Append(", experience=")
                                        .Append (datahub.User.Experience)
                                        .ToString();
        modifyDB.ControllDB(query, "user");
        builder.Clear();

        // ������ ���ȯ
        Daily_Connector.Connect();

        // Ȯ�� â ����
        ReciveConfirm.Instance.OpenConfirmWindow(announce_text, 0, 1);

    }

    public override void Recive(int id) {
        DailyQuest quest = datahub.DailyQuest[id] as DailyQuest;
        string announce;

        if (quest.CanRecive) {

            // ���� ����ġ ���� ����
            int reward_gold = (int)quest.RewardVal[0];
            int reward_exp = (int)quest.RewardVal[1];

            datahub.User.Dot += reward_gold;
            datahub.User.Experience += reward_exp;

            announce = builder.Append("��� + ")
                            .Append(reward_gold)
                            .Append("\n")
                            .Append("����ġ + ")
                            .Append(reward_exp)
                            .ToString();
            builder.Clear();

            quest.CanRecive = false;
            quest.Checker++;

            // dot ������Ʈ
            string query = builder.Append("UPDATE user SET dot=")
                                    .Append(datahub.User.Dot)
                                    .Append(", experience=")
                                    .Append(datahub.User.Experience)
                                    .ToString();
            modifyDB.ControllDB(query, "user");
            builder.Clear();

            // ������ checker�� ������Ʈ
            query = builder.Append("UPDATE dailyquest SET checker=")
                            .Append(quest.Checker)
                            .Append(" WHERE id=")
                            .Append(quest.Id)
                            .ToString();
            modifyDB.ControllDB(query, "daily");
            builder.Clear();

            // ���� update
            Daily_Connector.Connect();

            // pannel ����
            ReciveConfirm.Instance.OpenConfirmWindow(announce, 0, 1);
        }

    }
}