using UnityEngine;
using static ShapeDefenseSpace.GameData;

public class DamageObserver : SceneSingleton<DamageObserver>
{

    public void DamageUpdate() {
        // unitfield �� ���鼭 id�� �ڱ� �ڽ����� �����ϱ�
        int size = datahub.StageFieldNumber;
        for(int i = 1; i <= size; i++) {
            GameObject unit = datahub.StageField[i] as GameObject;
            if (unit.GetComponent<Field>().UnitId > 0) {
                unit.GetComponent<UnitAttack>().Id = unit.GetComponent<Field>().UnitId;
            }
        }
    }
}
